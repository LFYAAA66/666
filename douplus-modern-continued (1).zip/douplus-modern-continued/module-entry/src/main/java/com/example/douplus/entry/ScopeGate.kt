package com.example.douplus.entry

class ScopeGate {
    private val defaultScopes = setOf(
        "com.ss.android.ugc.aweme",
        "com.ss.android.ugc.aweme.mobile",
        "com.ss.android.ugc.aweme.lite",
        "com.ss.android.ugc.live",
        "com.ss.android.ugc.livelite",
    )

    fun accept(packageName: String, processName: String?): Boolean {
        return packageName in defaultScopes
    }
}
