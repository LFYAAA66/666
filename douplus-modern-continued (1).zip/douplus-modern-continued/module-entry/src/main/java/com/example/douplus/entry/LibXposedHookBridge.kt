package com.example.douplus.entry

import com.example.douplus.hookapi.HookBridge
import io.github.libxposed.api.XposedInterface
import java.lang.reflect.Method

class LibXposedHookBridge(
    private val module: DouPlusModule,
) : HookBridge {
    override fun installMethodHook(method: Method, hooker: Class<out XposedInterface.Hooker>): Any? = module.hook(method, hooker)
    override fun deoptimize(method: Method): Boolean = module.deoptimize(method)
}
