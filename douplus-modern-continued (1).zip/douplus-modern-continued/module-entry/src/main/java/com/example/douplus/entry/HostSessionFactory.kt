package com.example.douplus.entry

import com.example.douplus.core.logging.LogCenter
import com.example.douplus.hookapi.HostDescriptor
import com.example.douplus.hookapi.HostSession
import com.example.douplus.hookapi.HookBridge

class HostSessionFactory(private val logCenter: LogCenter) {
    fun create(
        packageName: String,
        processName: String,
        classLoader: ClassLoader,
        versionName: String? = null,
        versionCode: Long = -1L,
        hookBridge: HookBridge? = null,
    ): HostSession {
        logCenter.i("Create host session for $packageName / $processName")
        return HostSession(
            descriptor = HostDescriptor(
                packageName = packageName,
                processName = processName,
                versionName = versionName,
                versionCode = versionCode,
                isMainProcess = packageName == processName,
                classLoader = classLoader,
            ),
            hookBridge = hookBridge
        )
    }
}
