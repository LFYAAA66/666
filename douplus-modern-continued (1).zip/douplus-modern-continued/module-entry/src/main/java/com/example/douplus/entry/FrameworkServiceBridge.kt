package com.example.douplus.entry

import com.example.douplus.adapter.remote.CachedRuleStore
import com.example.douplus.adapter.report.AdaptationReport
import com.example.douplus.core.logging.LogCenter
import com.example.douplus.data.config.repository.ConfigRepository

class FrameworkServiceBridge(
    private val module: DouPlusModule,
    private val logCenter: LogCenter,
) {
    val configRepository: ConfigRepository = ConfigRepository()
    val ruleStore: CachedRuleStore = CachedRuleStore()

    fun initialize() {
        logCenter.i("FrameworkServiceBridge initialized")
    }

    fun persistReport(report: AdaptationReport) {
        logCenter.i("Adaptation report persisted: status=${report.status()} installed=${report.installedFeatures.size} failures=${report.failures.size}")
    }
}
