package com.example.douplus.entry

import com.example.douplus.adapter.engine.AdapterEngine
import com.example.douplus.adapter.report.AdaptationReport
import com.example.douplus.core.flags.FeatureFlagEvaluator
import com.example.douplus.core.logging.LogCenter
import com.example.douplus.feature.chat.ChatFeature
import com.example.douplus.feature.comment.CommentFeature
import com.example.douplus.feature.settings.SettingsEntryFeature
import com.example.douplus.feature.video.VideoFeature
import com.example.douplus.feature.ward.WardFeature
import com.example.douplus.hookapi.FeatureHookModule
import com.example.douplus.hookapi.HostSession

class FeatureBootstrapper(
    private val logCenter: LogCenter,
    frameworkServiceBridge: FrameworkServiceBridge,
) {
    private val configRepository = frameworkServiceBridge.configRepository
    private val flagEvaluator = FeatureFlagEvaluator()
    private val adapterEngine = AdapterEngine(logCenter)
    private val features: List<FeatureHookModule> = listOf(
        SettingsEntryFeature(logCenter, configRepository),
        VideoFeature(logCenter, configRepository),
        CommentFeature(logCenter, configRepository),
        WardFeature(logCenter),
        ChatFeature(logCenter, configRepository),
    )

    suspend fun installAll(hostSession: HostSession, report: AdaptationReport) {
        val targets = adapterEngine.resolveAll(hostSession.descriptor, report)
        val snapshot = configRepository.currentSnapshot()
        features.forEach { feature ->
            if (!feature.supportedPackages.contains(hostSession.descriptor.packageName)) return@forEach
            if (!feature.supportsVersion(hostSession.descriptor.versionCode)) return@forEach
            if (!flagEvaluator.isEnabled(feature.featureName, snapshot.enabledFeatures)) return@forEach
            val targetSet = targets[feature.featureName]
            if (targetSet == null) {
                report.recordFailure(feature.featureName, "AdapterEngine", "HookTargetSet", "Missing target set")
                return@forEach
            }
            val result = feature.install(hostSession, targetSet, report)
            if (result.installed) {
                report.recordInstalled(feature.featureName)
            } else {
                logCenter.w("Feature ${feature.featureName} not installed: ${result.message}")
            }
        }
    }
}
