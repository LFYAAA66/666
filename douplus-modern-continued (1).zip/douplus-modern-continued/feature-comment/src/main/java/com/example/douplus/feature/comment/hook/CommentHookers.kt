package com.example.douplus.feature.comment.hook

import com.example.douplus.core.android.HostUiTools
import io.github.libxposed.api.XposedInterface

class CommentBindHooker : XposedInterface.Hooker {
    companion object {
        @JvmStatic
        fun before(callback: XposedInterface.BeforeHookCallback) = Unit

        @JvmStatic
        fun after(callback: XposedInterface.AfterHookCallback) {
            val target = callback.thisObject ?: callback.result
            HostUiTools.bindLongPressActions(target, "抖+评论操作", listOf("插眼", "评论时间", "保存图片", "模块设置"))
        }
    }
}

class CommentMenuHooker : XposedInterface.Hooker {
    companion object {
        @JvmStatic
        fun before(callback: XposedInterface.BeforeHookCallback) = Unit

        @JvmStatic
        fun after(callback: XposedInterface.AfterHookCallback) {
            val target = callback.thisObject ?: callback.result
            HostUiTools.addModuleEntryBadge(target, "评论增强", "douplus_comment_menu_badge")
        }
    }
}
