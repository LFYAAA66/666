package com.example.douplus.feature.comment

import com.example.douplus.adapter.report.AdaptationReport
import com.example.douplus.adapter.targets.CommentTargets
import com.example.douplus.core.format.TimeFormatEngine
import com.example.douplus.core.logging.LogCenter
import com.example.douplus.core.reflection.HostReflectionResolver
import com.example.douplus.core.safety.HookIsolationRunner
import com.example.douplus.data.config.repository.ConfigRepository
import com.example.douplus.data.ward.entity.LocalFilterRuleEntity
import com.example.douplus.feature.comment.hook.CommentBindHooker
import com.example.douplus.feature.comment.hook.CommentMenuHooker
import com.example.douplus.hookapi.*

class CommentTimeFormatter(private val timeFormatEngine: TimeFormatEngine = TimeFormatEngine()) {
    fun format(originalText: String, timeMs: Long?, pattern: String): String {
        val timeText = timeMs?.let { timeFormatEngine.format(it, pattern) } ?: "unknown"
        return "${originalText} [$timeText]"
    }
}

class CommentFilterEngine {
    fun shouldHide(text: String?, rules: List<LocalFilterRuleEntity>): Boolean {
        return rules.any { it.ruleType == "keyword" && !it.ruleValue.isBlank() && text?.contains(it.ruleValue, ignoreCase = true) == true }
    }
    fun removeAtPrefix(text: String): String = text.replace(Regex("@[\\w._-]+\\s*"), "").trim()
}

class CommentPlaybackBridge
class CommentItemInterceptor
class CommentMenuContributor

class CommentFeature(
    private val logCenter: LogCenter,
    private val configRepository: ConfigRepository,
) : FeatureHookModule {
    override val featureName = "comment"
    override val supportedPackages = setOf(
        "com.ss.android.ugc.aweme",
        "com.ss.android.ugc.aweme.mobile",
        "com.ss.android.ugc.aweme.lite",
    )
    override fun supportsVersion(versionCode: Long): Boolean = true

    override fun install(hostSession: HostSession, targets: HookTargetSet, report: AdaptationReport): HookInstallResult {
        val typed = targets as? CommentTargets ?: return HookInstallResult(false, "wrong target type")
        val bridge = hostSession.hookBridge ?: return HookInstallResult(false, "missing hook bridge")
        val classLoader = hostSession.descriptor.classLoader
        val runner = HookIsolationRunner(logCenter)
        var ok = 0

        val bindResolved = HostReflectionResolver.resolveMethod(classLoader, typed.commentBindMethod)
        if (bindResolved != null) {
            if (runner.guarded(featureName, "CommentFeature", "commentBindMethod", report) {
                    bridge.installMethodHook(bindResolved.method, CommentBindHooker::class.java)
                    logCenter.i("Installed comment bind hook: ${HostReflectionResolver.dumpMethodSignature(bindResolved.method)}")
                }) ok++
        } else if (typed.commentBindMethod != null) {
            report.recordFailure(featureName, "CommentFeature", "commentBindMethod", "Failed to resolve comment bind method")
        }

        val menuResolved = HostReflectionResolver.resolveMethod(classLoader, typed.commentMenuBuildMethod)
        if (menuResolved != null) {
            runner.guarded(featureName, "CommentFeature", "commentMenuBuildMethod", report) {
                bridge.installMethodHook(menuResolved.method, CommentMenuHooker::class.java)
                logCenter.i("Installed comment menu hook: ${HostReflectionResolver.dumpMethodSignature(menuResolved.method)}")
            }
        } else if (typed.commentMenuBuildMethod != null) {
            report.recordFailure(featureName, "CommentFeature", "commentMenuBuildMethod", "Failed to resolve comment menu method")
        }

        return HookInstallResult(ok > 0, if (ok > 0) "comment installed" else "comment core target missing", partial = true)
    }
}
