package com.example.douplus.core.reflection

import com.example.douplus.hookapi.FieldRef
import com.example.douplus.hookapi.MethodRef
import com.example.douplus.hookapi.ResolvedField
import com.example.douplus.hookapi.ResolvedMethod
import java.lang.reflect.Method
import java.lang.reflect.Modifier

object HostReflectionResolver {
    fun resolveMethod(classLoader: ClassLoader, ref: MethodRef?): ResolvedMethod? {
        if (ref == null) return null
        if (ref.ownerHint.contains("待宿主定位") || ref.methodNameHint.contains("待宿主定位")) return null
        val ownerClass = runCatching { classLoader.loadClass(normalizeClassName(ref.ownerHint)) }.getOrNull() ?: return null
        val candidate = ownerClass.declaredMethods.firstOrNull { it.name == ref.methodNameHint && it.parameterTypes.size == ref.paramCount }
            ?: ownerClass.methods.firstOrNull { it.name == ref.methodNameHint && it.parameterTypes.size == ref.paramCount }
            ?: return null
        candidate.isAccessible = true
        return ResolvedMethod(ownerClass, candidate, ref)
    }

    fun resolveField(classLoader: ClassLoader, ref: FieldRef?): ResolvedField? {
        if (ref == null) return null
        if (ref.ownerHint.contains("待宿主定位") || ref.fieldNameHint.contains("待宿主定位")) return null
        val ownerClass = runCatching { classLoader.loadClass(normalizeClassName(ref.ownerHint)) }.getOrNull() ?: return null
        val candidate = runCatching { ownerClass.getDeclaredField(ref.fieldNameHint) }.getOrNull()
            ?: ownerClass.declaredFields.firstOrNull { field ->
                field.name == ref.fieldNameHint || (!ref.fieldTypeHint.isNullOrBlank() && field.type.name == ref.fieldTypeHint)
            }
            ?: return null
        candidate.isAccessible = true
        return ResolvedField(ownerClass, candidate, ref)
    }

    fun normalizeClassName(raw: String): String {
        var text = raw.trim()
        while (text.startsWith("L") && text.length > 2) text = text.substring(1)
        return text.removeSuffix(";").replace('/', '.')
    }

    fun dumpMethodSignature(method: Method): String {
        val visibility = when {
            Modifier.isPublic(method.modifiers) -> "public"
            Modifier.isProtected(method.modifiers) -> "protected"
            Modifier.isPrivate(method.modifiers) -> "private"
            else -> "package"
        }
        val params = method.parameterTypes.joinToString(",") { it.simpleName }
        return "$visibility ${method.declaringClass.name}#${method.name}($params):${method.returnType.simpleName}"
    }
}
