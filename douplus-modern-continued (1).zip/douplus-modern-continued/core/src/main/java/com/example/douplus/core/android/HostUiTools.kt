package com.example.douplus.core.android

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.ContextWrapper
import android.graphics.Color
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

object HostUiTools {
    fun tryFindContext(target: Any?): Context? {
        if (target == null) return null
        return when (target) {
            is Context -> target
            is View -> target.context
            else -> searchContextInFields(target)
        }
    }

    fun tryFindAnchorView(target: Any?): View? {
        if (target == null) return null
        if (target is View) return target
        val clsSeq = generateSequence(target.javaClass) { it.superclass }
        for (cls in clsSeq) {
            cls.declaredFields.forEach { field ->
                try {
                    field.isAccessible = true
                    val value = field.get(target)
                    if (value is View) return value
                } catch (_: Throwable) {
                }
            }
        }
        return null
    }

    fun showSimpleActions(target: Any?, title: String, items: List<String>) {
        val context = tryFindContext(target) ?: return
        val activity = context.findActivity() ?: return
        activity.runOnUiThread {
            try {
                AlertDialog.Builder(activity)
                    .setTitle(title)
                    .setItems(items.toTypedArray(), null)
                    .setNegativeButton("关闭", null)
                    .show()
            } catch (_: Throwable) {
            }
        }
    }

    fun addModuleEntryBadge(target: Any?, text: String, tag: String) {
        val view = tryFindAnchorView(target) ?: return
        val parent = view as? ViewGroup ?: (view.parent as? ViewGroup) ?: return
        if (parent.findViewWithTag<View>(tag) != null) return
        val context = parent.context ?: return
        val badge = TextView(context).apply {
            this.tag = tag
            this.text = text
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setPadding(dp(context, 8), dp(context, 4), dp(context, 8), dp(context, 4))
            setBackgroundColor(Color.parseColor("#CC3A3A3A"))
            alpha = 0.92f
            gravity = Gravity.CENTER
        }
        when (parent) {
            is FrameLayout -> {
                val lp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                lp.gravity = Gravity.END or Gravity.TOP
                lp.topMargin = dp(context, 8)
                lp.marginEnd = dp(context, 8)
                parent.addView(badge, lp)
            }
            is LinearLayout -> parent.addView(badge, 0)
            else -> parent.addView(badge)
        }
    }

    fun bindLongPressActions(target: Any?, title: String, items: List<String>) {
        val view = tryFindAnchorView(target) ?: return
        val existing = view.getTag(android.R.id.toggle)?.toString()
        if (existing == title) return
        view.setTag(android.R.id.toggle, title)
        view.setOnLongClickListener {
            showSimpleActions(it, title, items)
            true
        }
    }

    private fun searchContextInFields(target: Any): Context? {
        val clsSeq = generateSequence(target.javaClass) { it.superclass }
        for (cls in clsSeq) {
            cls.declaredFields.forEach { field ->
                try {
                    field.isAccessible = true
                    when (val value = field.get(target)) {
                        is Context -> return value
                        is View -> return value.context
                    }
                } catch (_: Throwable) {
                }
            }
        }
        return null
    }

    private fun Context.findActivity(): Activity? = when (this) {
        is Activity -> this
        is ContextWrapper -> baseContext.findActivity()
        else -> null
    }

    private fun dp(context: Context, value: Int): Int = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP,
        value.toFloat(),
        context.resources.displayMetrics
    ).toInt()
}
