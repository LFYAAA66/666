
package com.example.douplus.adapter.report

enum class AdaptationStatus {
    SUCCESS,
    PARTIAL_SUCCESS,
    FAILED
}

data class AdaptationFailure(
    val hostPackage: String,
    val hostVersionName: String? = null,
    val hostVersionCode: Long = -1,
    val featureName: String,
    val resolverName: String,
    val targetType: String,
    val reason: String,
    val throwableClass: String? = null,
    val stackTraceDigest: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
)

data class AdaptationReport(
    val hostPackage: String,
    val hostVersionName: String? = null,
    val hostVersionCode: Long = -1L,
    val installedFeatures: MutableSet<String> = linkedSetOf(),
    val failures: MutableList<AdaptationFailure> = mutableListOf(),
) {
    fun recordInstalled(featureName: String) {
        installedFeatures += featureName
    }

    fun recordFailure(
        featureName: String,
        resolverName: String,
        targetType: String,
        reason: String,
        throwable: Throwable? = null,
    ) {
        failures += AdaptationFailure(
            hostPackage = hostPackage,
            hostVersionName = hostVersionName,
            hostVersionCode = hostVersionCode,
            featureName = featureName,
            resolverName = resolverName,
            targetType = targetType,
            reason = reason,
            throwableClass = throwable?.javaClass?.name,
            stackTraceDigest = throwable?.stackTraceToString()?.take(1200),
        )
    }

    fun status(): AdaptationStatus {
        return when {
            installedFeatures.isNotEmpty() && failures.isEmpty() -> AdaptationStatus.SUCCESS
            installedFeatures.isNotEmpty() -> AdaptationStatus.PARTIAL_SUCCESS
            else -> AdaptationStatus.FAILED
        }
    }
}
