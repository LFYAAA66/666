package com.example.douplus.core.safety

import com.example.douplus.core.logging.LogCenter

class SafeRunner(private val logCenter: LogCenter) {
    fun run(tag: String, block: () -> Unit): SafeRunResult {
        return try {
            block()
            SafeRunResult.Success
        } catch (t: Throwable) {
            logCenter.e("SafeRunner[$tag] failed", t)
            SafeRunResult.Failure(t)
        }
    }
}

sealed interface SafeRunResult {
    data object Success : SafeRunResult
    data class Failure(val throwable: Throwable) : SafeRunResult
}
