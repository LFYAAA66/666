package com.example.douplus.core.flags

class FeatureFlagEvaluator {
    fun isEnabled(featureName: String, enabledFeatures: Map<String, Boolean>): Boolean {
        return enabledFeatures[featureName] ?: true
    }
}
