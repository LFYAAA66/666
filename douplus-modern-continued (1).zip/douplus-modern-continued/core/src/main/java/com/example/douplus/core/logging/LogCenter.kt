package com.example.douplus.core.logging

/** 双进程可用的轻量日志中心。 */
class LogCenter(
    private val printer: (String, Throwable?) -> Unit = { _, _ -> }
) {
    fun d(message: String) = printer("[D] $message", null)
    fun i(message: String) = printer("[I] $message", null)
    fun w(message: String) = printer("[W] $message", null)
    fun e(message: String, throwable: Throwable? = null) = printer("[E] $message", throwable)
}
