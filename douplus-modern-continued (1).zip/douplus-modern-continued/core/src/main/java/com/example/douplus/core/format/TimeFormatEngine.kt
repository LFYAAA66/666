package com.example.douplus.core.format

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class TimeFormatEngine {
    fun format(timestamp: Long, pattern: String, locale: Locale = Locale.getDefault()): String {
        return try {
            SimpleDateFormat(pattern, locale).format(Date(timestamp))
        } catch (_: Throwable) {
            SimpleDateFormat("yyyy-MM-dd HH:mm:ss", locale).format(Date(timestamp))
        }
    }
}
