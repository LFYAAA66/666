package com.example.douplus.core.result

sealed interface AppResult<out T> {
    data class Success<T>(val value: T) : AppResult<T>
    data class Failure(val reason: FailReason, val throwable: Throwable? = null) : AppResult<Nothing>
}

sealed interface FailReason {
    data object Unknown : FailReason
    data class Message(val text: String) : FailReason
}
