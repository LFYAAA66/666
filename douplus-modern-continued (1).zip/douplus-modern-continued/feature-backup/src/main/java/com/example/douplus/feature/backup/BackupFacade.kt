package com.example.douplus.feature.backup

import com.example.douplus.data.backup.*
import java.io.File

interface BackupFacade {
    suspend fun exportBackup(requireConfirm: Boolean = true): BackupResult
    suspend fun importBackup(file: File, requireConfirm: Boolean = true): BackupResult
    suspend fun uploadToWebDav(file: File, remoteDir: String, requireConfirm: Boolean = true): BackupResult
}

data class BackupResult(
    val success: Boolean,
    val message: String,
    val outputPath: String? = null,
)

class BackupFacadeImpl(
    private val writer: BackupPackageWriter,
    private val reader: BackupPackageReader,
    private val validator: RestoreValidator,
    private val webDavClientFacade: WebDavClientFacade,
    private val schemaVersion: Int = 1,
) : BackupFacade {
    override suspend fun exportBackup(requireConfirm: Boolean): BackupResult {
        if (requireConfirm) {
            // TODO("显式确认流程：导出备份")
        }
        return BackupResult(false, "Export requires app-side repository binding")
    }

    override suspend fun importBackup(file: File, requireConfirm: Boolean): BackupResult {
        if (requireConfirm) {
            // TODO("显式确认流程：导入备份")
        }
        val bundle = reader.read(file)
        return if (validator.validate(bundle, schemaVersion)) {
            BackupResult(true, "Backup bundle validated", file.absolutePath)
        } else {
            BackupResult(false, "Schema version mismatch")
        }
    }

    override suspend fun uploadToWebDav(file: File, remoteDir: String, requireConfirm: Boolean): BackupResult {
        if (requireConfirm) {
            // TODO("显式确认流程：上传到 WebDAV")
        }
        val ok = webDavClientFacade.upload(file, remoteDir)
        return BackupResult(ok, if (ok) "Uploaded" else "Upload failed", file.absolutePath)
    }
}

class AutoBackupScheduler {
    fun onSettingsChanged(autoEnabled: Boolean) {
        // TODO("应用侧调度自动备份")
    }
}
