# Build and CI notes

## What was added in this revision

- `libs/libxposed-api-stub.jar`: compileOnly stub so the project is easier to index and build in CI.
- `scripts/tools/extract_candidate_classes.py`: extracts keyword-based class candidates from `base.apk`.
- `docs/host-analysis/*candidate_classes*`: generated candidate class reports for Douyin `38.2.0 (380201)`.
- GitHub Actions now defaults to `local-stub` for libxposed strategy.

## Important limitation

The stub jar is **not** the real LSPosed Modern API. It is only for compilation and IDE assistance.
For real runtime validation you still need to verify hooks on-device and later replace the stub with real libxposed artifacts if necessary.
