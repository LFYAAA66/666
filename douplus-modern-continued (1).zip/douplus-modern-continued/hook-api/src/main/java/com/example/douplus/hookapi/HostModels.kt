package com.example.douplus.hookapi

data class HostDescriptor(
    val packageName: String,
    val processName: String,
    val versionName: String? = null,
    val versionCode: Long = -1L,
    val isMainProcess: Boolean,
    val classLoader: ClassLoader
)

data class HostContextSnapshot(
    val hostPackage: String,
    val pageName: String? = null,
    val objectType: String? = null,
    val objectId: String? = null,
    val title: String? = null,
    val summary: String? = null,
    val extra: Map<String, String> = emptyMap()
)

data class HostSession(
    val descriptor: HostDescriptor,
    val hookBridge: HookBridge? = null,
    val tags: Map<String, String> = emptyMap()
)
