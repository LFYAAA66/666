package com.example.douplus.hookapi

import com.example.douplus.adapter.report.AdaptationReport

interface HookTargetSet {
    val featureName: String
    val versionRangeLabel: String
    val confidenceScore: Int
    val isOptional: Boolean
    val degradeLevel: DegradeLevel
}

enum class DegradeLevel {
    NONE,
    PARTIAL,
    FEATURE_OFF
}

data class HookInstallPlan(
    val featureName: String,
    val supported: Boolean,
    val reason: String? = null
)

data class HookInstallResult(
    val installed: Boolean,
    val message: String,
    val partial: Boolean = false
)

interface FeatureHookModule {
    val featureName: String
    val supportedPackages: Set<String>
    fun supportsVersion(versionCode: Long): Boolean
    fun plan(hostSession: HostSession): HookInstallPlan = HookInstallPlan(featureName, true)
    fun install(hostSession: HostSession, targets: HookTargetSet, report: AdaptationReport): HookInstallResult
}
