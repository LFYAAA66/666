package com.example.douplus.hookapi

enum class UiInjectionPoint {
    TOP_MENU,
    BOTTOM_MENU,
    VIDEO_LONG_PRESS,
    PHOTO_LONG_PRESS,
    COMMENT_LONG_PRESS,
    CHAT_PANEL,
    VIDEO_PANEL,
    COMMENT_PANEL
}

data class MenuActionSpec(
    val id: String,
    val title: String,
    val injectionPoint: UiInjectionPoint,
    val dangerous: Boolean = false,
    val requiresConfirm: Boolean = false
)
