package com.example.douplus.hookapi

data class LazyClassRef(
    val ownerHint: String,
    val exactName: String? = null
)

data class MethodRef(
    val ownerHint: String,
    val methodNameHint: String,
    val paramCount: Int,
    val returnTypeHint: String? = null
)

data class FieldRef(
    val ownerHint: String,
    val fieldNameHint: String,
    val fieldTypeHint: String? = null
)
