package com.example.douplus.feature.chat

import com.example.douplus.adapter.report.AdaptationReport
import com.example.douplus.adapter.targets.ChatTargets
import com.example.douplus.core.format.TimeFormatEngine
import com.example.douplus.core.logging.LogCenter
import com.example.douplus.core.safety.HookIsolationRunner
import com.example.douplus.data.config.repository.ConfigRepository
import com.example.douplus.hookapi.*

class ChatTimeDecorator(private val timeFormatEngine: TimeFormatEngine = TimeFormatEngine()) {
    fun format(timestamp: Long?, pattern: String): String = timestamp?.let { timeFormatEngine.format(it, pattern) } ?: "unknown"
}

class LocalAudioPickerBridge
class TtsAssistController
class DiceAssistController

class ChatFeature(
    private val logCenter: LogCenter,
    private val configRepository: ConfigRepository,
) : FeatureHookModule {
    override val featureName: String = "chat"
    override val supportedPackages: Set<String> = setOf(
        "com.ss.android.ugc.aweme",
        "com.ss.android.ugc.aweme.mobile",
        "com.ss.android.ugc.aweme.lite",
    )

    override fun supportsVersion(versionCode: Long): Boolean = true

    override fun install(hostSession: HostSession, targets: HookTargetSet, report: AdaptationReport): HookInstallResult {
        val typed = targets as? ChatTargets ?: return HookInstallResult(false, "wrong target type")
        val runner = HookIsolationRunner(logCenter)
        var ok = false
        if (typed.messageBindMethod != null) {
            ok = runner.guarded(featureName, "ChatFeature", "messageBindMethod", report) {
                logCenter.i("Pretend install chat bind hook")
                // TODO("待宿主定位: 安装消息时间显示 Hook")
            } || ok
        }
        if (typed.sendPanelMethod != null) {
            runner.guarded(featureName, "ChatFeature", "sendPanelMethod", report) {
                logCenter.i("Pretend install send panel bridge")
                // TODO("待宿主定位: 安装本地音频 / TTS / 骰子辅助入口")
            }
        }
        return HookInstallResult(ok, if (ok) "chat installed" else "chat core target missing", partial = true)
    }
}
