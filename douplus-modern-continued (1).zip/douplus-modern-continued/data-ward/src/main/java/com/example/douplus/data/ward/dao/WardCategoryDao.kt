package com.example.douplus.data.ward.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.douplus.data.ward.entity.WardCategoryEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface WardCategoryDao {
    @Insert
    suspend fun insert(entity: WardCategoryEntity): Long

    @Update
    suspend fun update(entity: WardCategoryEntity)

    @Query("SELECT * FROM ward_categories ORDER BY isPinned DESC, sortOrder ASC, updatedAt DESC")
    fun observeAll(): Flow<List<WardCategoryEntity>>
}
