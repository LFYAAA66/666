package com.example.douplus.data.ward.db

import androidx.room.Database
import androidx.room.RoomDatabase
import com.example.douplus.data.ward.dao.*
import com.example.douplus.data.ward.entity.*

@Database(
    entities = [
        WardEntity::class,
        WardCategoryEntity::class,
        WardObjectRefEntity::class,
        LocalFilterRuleEntity::class,
        AdaptationFailureEntity::class,
        BackupManifestEntity::class,
    ],
    version = 1,
    exportSchema = true
)
abstract class DouPlusDatabase : RoomDatabase() {
    abstract fun wardDao(): WardDao
    abstract fun wardCategoryDao(): WardCategoryDao
    abstract fun wardObjectRefDao(): WardObjectRefDao
    abstract fun localFilterRuleDao(): LocalFilterRuleDao
    abstract fun adaptationFailureDao(): AdaptationFailureDao
    abstract fun backupManifestDao(): BackupManifestDao
}
