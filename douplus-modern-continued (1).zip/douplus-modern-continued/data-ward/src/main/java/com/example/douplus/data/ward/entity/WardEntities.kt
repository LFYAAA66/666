package com.example.douplus.data.ward.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "ward_categories",
    indices = [Index(value = ["name"], unique = true), Index(value = ["sortOrder", "isPinned"])]
)
data class WardCategoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val color: String? = null,
    val sortOrder: Int = 0,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val isPinned: Boolean = false,
    val extraJson: String? = null,
)

@Entity(
    tableName = "wards",
    indices = [
        Index(value = ["hostPackage", "objectType", "objectId"]),
        Index(value = ["categoryId", "createdAt"]),
        Index(value = ["updatedAt"]),
        Index(value = ["isDeleted", "updatedAt"]),
    ],
    foreignKeys = [
        ForeignKey(
            entity = WardCategoryEntity::class,
            parentColumns = ["id"],
            childColumns = ["categoryId"],
            onDelete = ForeignKey.SET_NULL
        )
    ]
)
data class WardEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val objectType: String,
    val objectId: String,
    val hostPackage: String,
    val title: String? = null,
    val summary: String? = null,
    val remark: String? = null,
    val categoryId: Long? = null,
    val sourcePage: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val extraJson: String? = null,
    val isDeleted: Boolean = false,
    val deletedAt: Long? = null,
)

@Entity(
    tableName = "ward_object_refs",
    indices = [Index(value = ["wardId"]), Index(value = ["refHostPackage", "refType", "refObjectId"]), Index(value = ["wardId", "refType", "refObjectId", "refHostPackage"], unique = true)],
    foreignKeys = [
        ForeignKey(entity = WardEntity::class, parentColumns = ["id"], childColumns = ["wardId"], onDelete = ForeignKey.CASCADE)
    ]
)
data class WardObjectRefEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val wardId: Long,
    val refType: String,
    val refObjectId: String,
    val refHostPackage: String,
    val createdAt: Long = System.currentTimeMillis(),
)

@Entity(
    tableName = "local_filter_rules",
    indices = [Index(value = ["featureArea", "isEnabled"]), Index(value = ["ruleType", "isEnabled"]), Index(value = ["featureArea", "ruleType", "ruleValue"], unique = true)]
)
data class LocalFilterRuleEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val featureArea: String,
    val ruleType: String,
    val ruleValue: String,
    val isEnabled: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
)

@Entity(
    tableName = "adaptation_failures",
    indices = [Index(value = ["hostPackage", "hostVersionCode", "featureName"]), Index(value = ["createdAt"])]
)
data class AdaptationFailureEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val hostPackage: String,
    val hostVersionName: String? = null,
    val hostVersionCode: Long = -1,
    val featureName: String,
    val resolverName: String,
    val targetType: String,
    val failReason: String,
    val stackTraceDigest: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
)

@Entity(
    tableName = "backup_manifests",
    indices = [Index(value = ["createdAt"]), Index(value = ["packageName", "backupType"]), Index(value = ["filePath"], unique = true)]
)
data class BackupManifestEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val packageName: String,
    val backupType: String,
    val fileName: String,
    val filePath: String,
    val fileHash: String,
    val appVersion: String,
    val schemaVersion: Int,
    val createdAt: Long = System.currentTimeMillis(),
)
