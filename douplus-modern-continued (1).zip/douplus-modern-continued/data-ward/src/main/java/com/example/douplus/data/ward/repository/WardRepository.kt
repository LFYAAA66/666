package com.example.douplus.data.ward.repository

import com.example.douplus.data.ward.dao.*
import com.example.douplus.data.ward.entity.*
import kotlinx.coroutines.flow.Flow

interface WardRepository {
    suspend fun insert(entity: WardEntity): Long
    suspend fun update(entity: WardEntity)
    suspend fun softDelete(id: Long)
    suspend fun exists(hostPackage: String, objectType: String, objectId: String): Boolean
    suspend fun search(keyword: String?, categoryId: Long?): List<WardEntity>
    suspend fun countByCategory(categoryId: Long): Int
    fun observeAll(): Flow<List<WardEntity>>
}

class WardRepositoryImpl(private val wardDao: WardDao) : WardRepository {
    override suspend fun insert(entity: WardEntity): Long = wardDao.insert(entity)
    override suspend fun update(entity: WardEntity) = wardDao.update(entity)
    override suspend fun softDelete(id: Long) = wardDao.softDelete(id)
    override suspend fun exists(hostPackage: String, objectType: String, objectId: String): Boolean = wardDao.exists(hostPackage, objectType, objectId)
    override suspend fun search(keyword: String?, categoryId: Long?): List<WardEntity> = wardDao.search(keyword, categoryId)
    override suspend fun countByCategory(categoryId: Long): Int = wardDao.countByCategory(categoryId)
    override fun observeAll(): Flow<List<WardEntity>> = wardDao.observeAll()
}

class WardCategoryRepository(private val wardCategoryDao: WardCategoryDao) {
    suspend fun insert(entity: WardCategoryEntity): Long = wardCategoryDao.insert(entity)
    suspend fun update(entity: WardCategoryEntity) = wardCategoryDao.update(entity)
    fun observeAll(): Flow<List<WardCategoryEntity>> = wardCategoryDao.observeAll()
}

class LocalFilterRuleRepository(private val dao: LocalFilterRuleDao) {
    suspend fun insert(entity: LocalFilterRuleEntity): Long = dao.insert(entity)
    suspend fun getEnabled(featureArea: String): List<LocalFilterRuleEntity> = dao.getEnabled(featureArea)
    fun observeAll(): Flow<List<LocalFilterRuleEntity>> = dao.observeAll()
}

class AdaptationFailureRepository(private val dao: AdaptationFailureDao) {
    suspend fun insert(entity: AdaptationFailureEntity): Long = dao.insert(entity)
    suspend fun listForHost(hostPackage: String): List<AdaptationFailureEntity> = dao.listForHost(hostPackage)
}

class BackupManifestRepository(private val dao: BackupManifestDao) {
    suspend fun insert(entity: BackupManifestEntity): Long = dao.insert(entity)
    fun observeAll(): Flow<List<BackupManifestEntity>> = dao.observeAll()
}
