package com.example.douplus.data.ward.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.douplus.data.ward.entity.WardEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface WardDao {
    @Insert
    suspend fun insert(entity: WardEntity): Long

    @Update
    suspend fun update(entity: WardEntity)

    @Query("UPDATE wards SET isDeleted = 1, deletedAt = :deletedAt, updatedAt = :deletedAt WHERE id = :id")
    suspend fun softDelete(id: Long, deletedAt: Long = System.currentTimeMillis())

    @Query("SELECT EXISTS(SELECT 1 FROM wards WHERE hostPackage = :hostPackage AND objectType = :objectType AND objectId = :objectId AND isDeleted = 0)")
    suspend fun exists(hostPackage: String, objectType: String, objectId: String): Boolean

    @Query("SELECT * FROM wards WHERE isDeleted = 0 ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<WardEntity>>

    @Query("""
        SELECT * FROM wards
        WHERE isDeleted = 0
          AND (:categoryId IS NULL OR categoryId = :categoryId)
          AND (:keyword IS NULL OR title LIKE '%' || :keyword || '%' OR summary LIKE '%' || :keyword || '%' OR remark LIKE '%' || :keyword || '%')
        ORDER BY updatedAt DESC
    """)
    suspend fun search(keyword: String?, categoryId: Long?): List<WardEntity>

    @Query("SELECT COUNT(*) FROM wards WHERE categoryId = :categoryId AND isDeleted = 0")
    suspend fun countByCategory(categoryId: Long): Int
}
