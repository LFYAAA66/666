package com.example.douplus.data.ward.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.example.douplus.data.ward.entity.*
import kotlinx.coroutines.flow.Flow

@Dao
interface WardObjectRefDao {
    @Insert
    suspend fun insert(entity: WardObjectRefEntity): Long
}

@Dao
interface LocalFilterRuleDao {
    @Insert
    suspend fun insert(entity: LocalFilterRuleEntity): Long

    @Query("SELECT * FROM local_filter_rules WHERE featureArea = :featureArea AND isEnabled = 1 ORDER BY updatedAt DESC")
    suspend fun getEnabled(featureArea: String): List<LocalFilterRuleEntity>

    @Query("SELECT * FROM local_filter_rules ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<LocalFilterRuleEntity>>
}

@Dao
interface AdaptationFailureDao {
    @Insert
    suspend fun insert(entity: AdaptationFailureEntity): Long

    @Query("SELECT * FROM adaptation_failures WHERE hostPackage = :hostPackage ORDER BY createdAt DESC")
    suspend fun listForHost(hostPackage: String): List<AdaptationFailureEntity>
}

@Dao
interface BackupManifestDao {
    @Insert
    suspend fun insert(entity: BackupManifestEntity): Long

    @Query("SELECT * FROM backup_manifests ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<BackupManifestEntity>>
}
