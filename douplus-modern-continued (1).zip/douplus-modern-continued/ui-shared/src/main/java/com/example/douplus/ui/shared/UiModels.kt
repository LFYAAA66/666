package com.example.douplus.ui.shared

data class SettingItemModel(
    val key: String,
    val title: String,
    val summary: String? = null,
    val enabled: Boolean = true,
)

data class ConfirmActionDialogModel(
    val title: String,
    val message: String,
    val confirmText: String = "确定",
    val cancelText: String = "取消",
)

data class DiagnosticCardModel(
    val title: String,
    val status: String,
    val content: String,
)

data class ColorPickerState(
    val selectedHex: String = "#FFFFFF"
)

data class BackupProgressState(
    val running: Boolean = false,
    val message: String = "",
)
