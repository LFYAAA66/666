
把通过 mavenLocal() 或者本地 Maven 仓库生成的 libxposed 依赖放到这里。
当前工程默认优先使用：
1. libs/*.aar
2. repo/ 本地 Maven 仓库
3. GitHub Actions 的远程准备脚本（需用户自己提供 URL）
