package com.example.douplus.feature.ward

import com.example.douplus.data.ward.entity.WardCategoryEntity
import com.example.douplus.data.ward.entity.WardEntity
import com.example.douplus.data.ward.repository.WardCategoryRepository
import com.example.douplus.data.ward.repository.WardRepository
import kotlinx.coroutines.flow.Flow

data class WardDraft(
    val objectType: String,
    val objectId: String,
    val hostPackage: String,
    val title: String? = null,
    val summary: String? = null,
    val remark: String? = null,
    val categoryId: Long? = null,
    val sourcePage: String? = null,
    val extraJson: String? = null,
)

interface WardFacade {
    suspend fun createDraft(draft: WardDraft): Long
    suspend fun deleteWard(id: Long)
    suspend fun exists(hostPackage: String, objectType: String, objectId: String): Boolean
    suspend fun search(keyword: String?, categoryId: Long?): List<WardEntity>
    suspend fun countByCategory(categoryId: Long): Int
    fun observeAll(): Flow<List<WardEntity>>
}

class WardFacadeImpl(
    private val repository: WardRepository,
) : WardFacade {
    override suspend fun createDraft(draft: WardDraft): Long {
        return repository.insert(
            WardEntity(
                objectType = draft.objectType,
                objectId = draft.objectId,
                hostPackage = draft.hostPackage,
                title = draft.title,
                summary = draft.summary,
                remark = draft.remark,
                categoryId = draft.categoryId,
                sourcePage = draft.sourcePage,
                extraJson = draft.extraJson,
            )
        )
    }

    override suspend fun deleteWard(id: Long) = repository.softDelete(id)
    override suspend fun exists(hostPackage: String, objectType: String, objectId: String): Boolean = repository.exists(hostPackage, objectType, objectId)
    override suspend fun search(keyword: String?, categoryId: Long?): List<WardEntity> = repository.search(keyword, categoryId)
    override suspend fun countByCategory(categoryId: Long): Int = repository.countByCategory(categoryId)
    override fun observeAll(): Flow<List<WardEntity>> = repository.observeAll()
}

class WardCategoryManager(
    private val categoryRepository: WardCategoryRepository,
) {
    suspend fun create(name: String, color: String? = null, pinned: Boolean = false): Long {
        return categoryRepository.insert(WardCategoryEntity(name = name, color = color, isPinned = pinned))
    }

    fun observeAll() = categoryRepository.observeAll()
}
