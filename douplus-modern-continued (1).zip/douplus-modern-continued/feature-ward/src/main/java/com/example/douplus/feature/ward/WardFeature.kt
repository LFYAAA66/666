
package com.example.douplus.feature.ward

import com.example.douplus.adapter.report.AdaptationReport
import com.example.douplus.adapter.targets.WardTargets
import com.example.douplus.core.logging.LogCenter
import com.example.douplus.core.safety.HookIsolationRunner
import com.example.douplus.hookapi.FeatureHookModule
import com.example.douplus.hookapi.HookInstallResult
import com.example.douplus.hookapi.HookTargetSet
import com.example.douplus.hookapi.HostSession

class WardFeature(
    private val logCenter: LogCenter,
) : FeatureHookModule {
    override val featureName: String = "ward"
    override val supportedPackages: Set<String> = setOf(
        "com.ss.android.ugc.aweme",
        "com.ss.android.ugc.aweme.mobile",
        "com.ss.android.ugc.aweme.lite",
        "com.ss.android.ugc.live",
        "com.ss.android.ugc.livelite",
    )

    override fun supportsVersion(versionCode: Long): Boolean = true

    override fun install(hostSession: HostSession, targets: HookTargetSet, report: AdaptationReport): HookInstallResult {
        val typed = targets as? WardTargets ?: return HookInstallResult(false, "wrong target type")
        val runner = HookIsolationRunner(logCenter)
        var ok = false
        if (typed.contextExtractMethod != null) {
            ok = runner.guarded(featureName, "WardFeature", "contextExtractMethod", report) {
                logCenter.i("Pretend install ward context hook: ${typed.contextExtractMethod}")
                // TODO("待宿主定位: 提取当前视频/评论/用户上下文")
            } || ok
        }
        if (typed.entryInjectMethod != null) {
            ok = runner.guarded(featureName, "WardFeature", "entryInjectMethod", report) {
                logCenter.i("Pretend install ward entry hook: ${typed.entryInjectMethod}")
                // TODO("待宿主定位: 注入插眼入口")
            } || ok
        }
        return HookInstallResult(ok, if (ok) "ward installed" else "ward core target missing", partial = true)
    }
}
