package com.example.douplus.feature.ward

import com.example.douplus.data.ward.repository.WardRepository

class CreateWardUseCase(private val facade: WardFacade) {
    suspend operator fun invoke(draft: WardDraft): Long = facade.createDraft(draft)
}

class UpdateWardUseCase(private val repository: WardRepository) {
    suspend operator fun invoke(entity: com.example.douplus.data.ward.entity.WardEntity) = repository.update(entity)
}

class DeleteWardUseCase(private val facade: WardFacade) {
    suspend operator fun invoke(id: Long) = facade.deleteWard(id)
}

class SearchWardUseCase(private val facade: WardFacade) {
    suspend operator fun invoke(keyword: String?, categoryId: Long?) = facade.search(keyword, categoryId)
}

class WardStatsUseCase(private val facade: WardFacade) {
    suspend fun countByCategory(categoryId: Long): Int = facade.countByCategory(categoryId)
}

class WardEntryComposer {
    fun composeFromContext(
        hostPackage: String,
        objectType: String,
        objectId: String,
        title: String? = null,
        summary: String? = null,
        sourcePage: String? = null,
    ): WardDraft {
        return WardDraft(
            objectType = objectType,
            objectId = objectId,
            hostPackage = hostPackage,
            title = title,
            summary = summary,
            sourcePage = sourcePage,
        )
    }
}
