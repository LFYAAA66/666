package com.example.douplus.data.config.remote

import android.content.SharedPreferences
import io.github.libxposed.api.XposedInterface

/**
 * 宿主进程只读视角的 Remote Preferences 封装。
 */
class RemotePreferenceStore(
    private val xposed: XposedInterface,
    private val groupName: String = "main"
) {
    private val prefs: SharedPreferences by lazy {
        xposed.getRemotePreferences(groupName)
    }

    fun getBoolean(key: String, defaultValue: Boolean = false): Boolean = prefs.getBoolean(key, defaultValue)
    fun getString(key: String, defaultValue: String? = null): String? = prefs.getString(key, defaultValue)
    fun getInt(key: String, defaultValue: Int = 0): Int = prefs.getInt(key, defaultValue)
    fun snapshot(): Map<String, *> = prefs.all
}
