package com.example.douplus.data.config.local

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.example.douplus.data.config.model.FeatureSettingsSnapshot
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.settingsDataStore by preferencesDataStore(name = "douplus_settings")

class AppSettingsStore(private val context: Context) {
    companion object {
        private val FEATURE_SETTINGS = booleanPreferencesKey("feature.settings.enabled")
        private val FEATURE_VIDEO = booleanPreferencesKey("feature.video.enabled")
        private val FEATURE_COMMENT = booleanPreferencesKey("feature.comment.enabled")
        private val FEATURE_WARD = booleanPreferencesKey("feature.ward.enabled")
        private val FEATURE_BACKUP = booleanPreferencesKey("feature.backup.enabled")
        private val FEATURE_CHAT = booleanPreferencesKey("feature.chat.enabled")
        private val COMMENT_TIME_FORMAT = stringPreferencesKey("comment.time.format")
        private val VIDEO_SHOW_TIME = booleanPreferencesKey("video.show.time")
        private val VIDEO_SHOW_LOCATION = booleanPreferencesKey("video.show.location")
        private val VIDEO_TEXT_SIZE = intPreferencesKey("video.text.size")
        private val VIDEO_TEXT_COLOR = stringPreferencesKey("video.text.color")
        private val VIDEO_COLORFUL = booleanPreferencesKey("video.colorful")
        private val COMMENT_COPY_REMOVE_AT = booleanPreferencesKey("comment.copy.remove.at")
        private val COMMENT_PAUSE_VIDEO = booleanPreferencesKey("comment.pause.video")
        private val COMMENT_SHOW_TIME = booleanPreferencesKey("comment.show.time")
        private val REMOTE_RULES = booleanPreferencesKey("remote.rules.enabled")
        private val BACKUP_AUTO = booleanPreferencesKey("backup.auto.enabled")
        private val WEBDAV_URL = stringPreferencesKey("webdav.url")
        private val WEBDAV_USER = stringPreferencesKey("webdav.user")
        private val WEBDAV_DIR = stringPreferencesKey("webdav.dir")
    }

    suspend fun updateFeature(feature: String, enabled: Boolean) {
        context.settingsDataStore.edit { prefs ->
            when (feature) {
                "settings" -> prefs[FEATURE_SETTINGS] = enabled
                "video" -> prefs[FEATURE_VIDEO] = enabled
                "comment" -> prefs[FEATURE_COMMENT] = enabled
                "ward" -> prefs[FEATURE_WARD] = enabled
                "backup" -> prefs[FEATURE_BACKUP] = enabled
                "chat" -> prefs[FEATURE_CHAT] = enabled
            }
        }
    }

    suspend fun updateBooleanByUiKey(key: String, enabled: Boolean) {
        context.settingsDataStore.edit { prefs ->
            when (key) {
                "video.show.time" -> prefs[VIDEO_SHOW_TIME] = enabled
                "video.show.location" -> prefs[VIDEO_SHOW_LOCATION] = enabled
                "remote.rules.enabled" -> prefs[REMOTE_RULES] = enabled
                "comment.copy.remove.at" -> prefs[COMMENT_COPY_REMOVE_AT] = enabled
                "comment.pause.video" -> prefs[COMMENT_PAUSE_VIDEO] = enabled
                "comment.show.time" -> prefs[COMMENT_SHOW_TIME] = enabled
                "backup.auto.enabled" -> prefs[BACKUP_AUTO] = enabled
            }
        }
    }

    fun currentEnabledForUiKey(snapshot: FeatureSettingsSnapshot, key: String, fallback: Boolean): Boolean {
        return when (key) {
            "video.show.time" -> snapshot.videoShowPublishTime
            "video.show.location" -> snapshot.videoShowPublishLocation
            "remote.rules.enabled" -> snapshot.remoteRuleUpdateEnabled
            "comment.copy.remove.at" -> snapshot.commentCopyRemoveAt
            "comment.pause.video" -> snapshot.commentPauseVideo
            "comment.show.time" -> true
            "backup.auto.enabled" -> snapshot.backupAutoEnabled
            else -> fallback
        }
    }

    suspend fun setCommentTimeFormat(pattern: String) {
        context.settingsDataStore.edit { it[COMMENT_TIME_FORMAT] = pattern }
    }

    suspend fun setVideoTextStyle(sizeSp: Int, colorHex: String, colorful: Boolean) {
        context.settingsDataStore.edit {
            it[VIDEO_TEXT_SIZE] = sizeSp
            it[VIDEO_TEXT_COLOR] = colorHex
            it[VIDEO_COLORFUL] = colorful
        }
    }

    suspend fun setWebDavConfig(baseUrl: String?, username: String?, remoteDir: String?) {
        context.settingsDataStore.edit {
            if (baseUrl != null) it[WEBDAV_URL] = baseUrl
            if (username != null) it[WEBDAV_USER] = username
            if (remoteDir != null) it[WEBDAV_DIR] = remoteDir
        }
    }

    fun observeSnapshot(): Flow<FeatureSettingsSnapshot> {
        return context.settingsDataStore.data.map { prefs ->
            FeatureSettingsSnapshot(
                enabledFeatures = mapOf(
                    "settings" to (prefs[FEATURE_SETTINGS] ?: true),
                    "video" to (prefs[FEATURE_VIDEO] ?: true),
                    "comment" to (prefs[FEATURE_COMMENT] ?: true),
                    "ward" to (prefs[FEATURE_WARD] ?: true),
                    "backup" to (prefs[FEATURE_BACKUP] ?: true),
                    "chat" to (prefs[FEATURE_CHAT] ?: true),
                ),
                commentTimeFormat = prefs[COMMENT_TIME_FORMAT] ?: "yyyy-MM-dd HH:mm:ss",
                remoteRuleUpdateEnabled = prefs[REMOTE_RULES] ?: true,
                videoShowPublishTime = prefs[VIDEO_SHOW_TIME] ?: true,
                videoShowPublishLocation = prefs[VIDEO_SHOW_LOCATION] ?: true,
                videoTextSizeSp = prefs[VIDEO_TEXT_SIZE] ?: 14,
                videoTextColorHex = prefs[VIDEO_TEXT_COLOR] ?: "#FFFFFF",
                videoColorfulDisplay = prefs[VIDEO_COLORFUL] ?: false,
                commentCopyRemoveAt = prefs[COMMENT_COPY_REMOVE_AT] ?: true,
                commentPauseVideo = prefs[COMMENT_PAUSE_VIDEO] ?: true,
                backupAutoEnabled = prefs[BACKUP_AUTO] ?: false,
                webDavBaseUrl = prefs[WEBDAV_URL],
                webDavUserName = prefs[WEBDAV_USER],
                webDavRemoteDir = prefs[WEBDAV_DIR],
            )
        }
    }

    suspend fun currentSnapshot(): FeatureSettingsSnapshot = observeSnapshot().first()
}
