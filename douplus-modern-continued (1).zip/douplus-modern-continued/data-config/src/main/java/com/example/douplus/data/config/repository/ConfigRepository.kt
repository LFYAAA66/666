package com.example.douplus.data.config.repository

import com.example.douplus.data.config.local.AppSettingsStore
import com.example.douplus.data.config.model.FeatureSettingsSnapshot
import com.example.douplus.data.config.remote.RemotePreferenceStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf

class ConfigRepository(
    private val appSettingsStore: AppSettingsStore? = null,
    private val remotePreferenceStore: RemotePreferenceStore? = null,
) {
    fun observeSnapshot(): Flow<FeatureSettingsSnapshot> {
        return appSettingsStore?.observeSnapshot() ?: flowOf(defaultSnapshot())
    }

    suspend fun currentSnapshot(): FeatureSettingsSnapshot {
        return appSettingsStore?.currentSnapshot() ?: defaultSnapshot()
    }

    private fun defaultSnapshot(): FeatureSettingsSnapshot {
        return FeatureSettingsSnapshot(
            enabledFeatures = mapOf(
                "settings" to true,
                "video" to true,
                "comment" to true,
                "ward" to true,
                "backup" to true,
                "chat" to true,
            )
        )
    }
}
