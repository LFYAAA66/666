package com.example.douplus.data.config.model

data class FeatureSettingsSnapshot(
    val enabledFeatures: Map<String, Boolean> = emptyMap(),
    val commentTimeFormat: String = "yyyy-MM-dd HH:mm:ss",
    val remoteRuleUpdateEnabled: Boolean = true,
    val videoShowPublishTime: Boolean = true,
    val videoShowPublishLocation: Boolean = true,
    val videoTextSizeSp: Int = 14,
    val videoTextColorHex: String = "#FFFFFF",
    val videoColorfulDisplay: Boolean = false,
    val commentCopyRemoveAt: Boolean = true,
    val commentPauseVideo: Boolean = true,
    val backupAutoEnabled: Boolean = false,
    val webDavBaseUrl: String? = null,
    val webDavUserName: String? = null,
    val webDavRemoteDir: String? = null,
)
