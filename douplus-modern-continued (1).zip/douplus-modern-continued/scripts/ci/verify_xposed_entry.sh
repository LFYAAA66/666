#!/usr/bin/env bash
set -euo pipefail
BASE="app/src/main/resources/META-INF/xposed"
for f in "$BASE/java_init.list" "$BASE/scope.list" "$BASE/module.prop"; do
  test -f "$f" && test -s "$f" || { echo "Missing or empty: $f"; exit 1; }
done
grep -q '^minApiVersion=' "$BASE/module.prop"
grep -q '^targetApiVersion=' "$BASE/module.prop"
grep -q '^staticScope=' "$BASE/module.prop"
for p in com.ss.android.ugc.aweme com.ss.android.ugc.aweme.mobile com.ss.android.ugc.aweme.lite com.ss.android.ugc.live com.ss.android.ugc.livelite; do
  grep -qx "$p" "$BASE/scope.list" || { echo "scope.list missing $p"; exit 1; }
done
echo OK
