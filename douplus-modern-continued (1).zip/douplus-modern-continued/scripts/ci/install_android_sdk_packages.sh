#!/usr/bin/env bash
set -euo pipefail
sdkmanager --package_file=scripts/ci/sdk-packages.txt
