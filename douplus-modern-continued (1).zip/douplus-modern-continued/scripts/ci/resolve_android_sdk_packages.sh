#!/usr/bin/env bash
set -euo pipefail
COMPILE_SDK="${1:-34}"
BUILD_TOOLS="${2:-34.0.0}"
printf 'platform-tools\nplatforms;android-%s\nbuild-tools;%s\n' "$COMPILE_SDK" "$BUILD_TOOLS" > scripts/ci/sdk-packages.txt
cat scripts/ci/sdk-packages.txt
