#!/usr/bin/env bash
set -euo pipefail
TYPE="${1:-debug}"
APK=$(ls -1 app/build/outputs/apk/${TYPE}/*.apk | head -n 1)
unzip -l "$APK" | grep -E 'META-INF/xposed/(java_init\.list|scope\.list|module\.prop)'
