#!/usr/bin/env bash
set -euo pipefail
STRATEGY="${LIBXPOSED_STRATEGY:-local-stub}"
URL="${LIBXPOSED_REMOTE_AAR_URL:-}"
mkdir -p libs repo
case "$STRATEGY" in
  local-stub)
    if ls libs/*libxposed*stub*.jar >/dev/null 2>&1; then
      echo "Using local compileOnly libxposed stub jar"
    else
      echo "Missing local stub jar in libs/"
      exit 1
    fi
    ;;
  bundled-aar)
    if ls libs/*.aar >/dev/null 2>&1; then
      echo "Using bundled local AAR/JAR artifacts from libs/"
    elif ls libs/*.jar >/dev/null 2>&1; then
      echo "Using bundled local JAR artifacts from libs/"
    else
      echo "Please place real libxposed AAR/JAR in libs/ or use local-stub"
      exit 1
    fi
    ;;
  local-maven)
    test -d repo || { echo "repo/ does not exist"; exit 1; }
    ;;
  remote-download)
    test -n "$URL" || { echo "remote-download mode requires URL"; exit 1; }
    echo "Remote download endpoint reserved; download step intentionally disabled by default."
    exit 1
    ;;
  *)
    echo "Unknown libxposed strategy: $STRATEGY"; exit 1
    ;;
esac
