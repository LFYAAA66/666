
#!/usr/bin/env python3
import json
import os
import sys
from pathlib import Path

def main(hints_json: str, out_dir: str, host_package: str, host_version_name: str, host_version_code: str):
    data = json.loads(Path(hints_json).read_text(encoding='utf-8'))
    os.makedirs(out_dir, exist_ok=True)
    for feature in ['settings', 'video', 'comment', 'ward', 'chat']:
        hints = []
        for line in data.get(feature, [])[:30]:
            hints.append({
                'type': 'stringHint',
                'value': line,
                'status': 'candidate'
            })
        payload = {
            'schemaVersion': 1,
            'hostPackage': host_package,
            'hostVersionCode': int(host_version_code),
            'hostVersionName': host_version_name,
            'feature': feature,
            'hints': hints or [{'type': 'placeholder', 'note': 'No hints found', 'status': 'pending'}],
        }
        Path(out_dir, f'{feature}.json').write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf-8')

if __name__ == '__main__':
    if len(sys.argv) != 6:
        print('Usage: generate_rule_templates.py <hints_json> <out_dir> <host_package> <host_version_name> <host_version_code>')
        raise SystemExit(1)
    main(*sys.argv[1:])
