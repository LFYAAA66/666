#!/usr/bin/env python3
import argparse, zipfile, re, json, pathlib, collections
PRINTABLE=re.compile(rb'[ -~]{4,}')
KEYWORDS=['comment','video','aweme','detail','digg','bury','music','player','feed','panel','menu','share','dialog','reply','pause','resume','chat','message','dice','audio','tts','ward']

def extract_ascii_strings(data: bytes):
    seen=set()
    for m in PRINTABLE.finditer(data):
        s=m.group().decode('latin1', errors='ignore')
        if len(s)>=4:
            seen.add(s)
    return seen

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('apk')
    ap.add_argument('--out', required=True)
    args=ap.parse_args()
    hits=collections.defaultdict(list)
    with zipfile.ZipFile(args.apk) as z:
        dex=[n for n in z.namelist() if re.fullmatch(r'classes\d*\.dex', n)]
        for name in dex:
            data=z.read(name)
            strings=extract_ascii_strings(data)
            for kw in KEYWORDS:
                matched=[s for s in strings if kw.lower() in s.lower()]
                matched=sorted(matched)[:300]
                if matched:
                    hits[kw].extend(f'{name}: {s}' for s in matched[:80])
    out=pathlib.Path(args.out)
    out.write_text(json.dumps(hits, ensure_ascii=False, indent=2), encoding='utf-8')
    md=out.with_suffix('.md')
    lines=['# DEX String Hints','']
    for kw in KEYWORDS:
        vals=hits.get(kw, [])
        lines.append(f'## {kw} ({len(vals)})')
        lines.extend(f'- `{v}`' for v in vals[:120])
        lines.append('')
    md.write_text('\n'.join(lines), encoding='utf-8')

if __name__=='__main__':
    main()
