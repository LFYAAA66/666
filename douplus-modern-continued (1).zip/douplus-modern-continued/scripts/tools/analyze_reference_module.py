#!/usr/bin/env python3
import collections
import json
import re
import sys
import zipfile
from pathlib import Path


def main(apk_path: str, out_dir: str):
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(apk_path) as zf:
        names = zf.namelist()
        dexes = [n for n in names if n.endswith('.dex')]
        xposed_init = None
        if 'assets/xposed_init' in names:
            xposed_init = zf.read('assets/xposed_init').decode('utf-8', 'replace').strip()

        packages = collections.Counter()
        classes = []
        for dex in dexes:
            data = zf.read(dex)
            for raw in set(re.findall(rb'(?:[A-Za-z0-9_$]+/){2,}[A-Za-z0-9_$]+', data)):
                text = raw.decode('utf-8', 'ignore')
                if text.startswith(('io/kazutoiris', 'io/yukihookapi', 'com/ss/android/ugc/aweme')):
                    packages['/'.join(text.split('/')[:4])] += 1
                    if any(key in text.lower() for key in ('comment', 'video', 'menu', 'setting', 'prefs')):
                        classes.append({'name': text.replace('/', '.'), 'dex': dex})

    payload = {
        'apk': apk_path,
        'xposed_init': xposed_init,
        'dex_count': len(dexes),
        'top_packages': packages.most_common(30),
        'interesting_classes': classes[:200],
    }
    (out / 'reference_module_summary.json').write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf-8')
    (out / 'reference_module_summary.md').write_text(
        '# 参考模块静态摘要\n\n'
        f'- 入口: `{xposed_init}`\n'
        f'- DEX 数量: {len(dexes)}\n',
        encoding='utf-8'
    )


if __name__ == '__main__':
    if len(sys.argv) < 3:
        print('usage: analyze_reference_module.py <apk> <out_dir>')
        sys.exit(1)
    main(sys.argv[1], sys.argv[2])
