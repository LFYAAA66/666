#!/usr/bin/env python3
import json, os, re, sys, zipfile
from collections import defaultdict
KEYWORDS = {
    'settings': ['setting', 'dialog', 'menu'],
    'video': ['aweme', 'video', 'player', 'feed', 'detail'],
    'comment': ['comment', 'reply', 'digg', 'bury'],
    'ward': ['comment', 'aweme', 'user', 'detail'],
    'chat': ['im/', 'chat', 'message', 'sendpanel', 'audio']
}

def iter_class_descriptors(apk_path):
    with zipfile.ZipFile(apk_path) as zf:
        for dex_name in [n for n in zf.namelist() if n.endswith('.dex')]:
            data = zf.read(dex_name)
            for m in re.finditer(rb'L([A-Za-z0-9_/$-]{5,240});', data):
                yield dex_name, m.group(1).decode('latin1', 'ignore')


def score(desc, terms):
    lower = desc.lower()
    s = 0
    for term in terms:
        if term.lower() in lower:
            s += 1
    return s


def main():
    if len(sys.argv) < 3:
        print('Usage: extract_candidate_classes.py <base.apk> <output.json>')
        sys.exit(2)
    apk_path, output_json = sys.argv[1], sys.argv[2]
    buckets = defaultdict(list)
    seen = set()
    for dex_name, desc in iter_class_descriptors(apk_path):
        if desc in seen:
            continue
        seen.add(desc)
        for feature, terms in KEYWORDS.items():
            sc = score(desc, terms)
            if sc > 0:
                buckets[feature].append({
                    'classDescriptor': 'L' + desc + ';',
                    'dex': dex_name,
                    'score': sc
                })
    result = {}
    for feature, arr in buckets.items():
        arr.sort(key=lambda x: (-x['score'], x['classDescriptor']))
        result[feature] = arr[:200]
    with open(output_json, 'w', encoding='utf-8') as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    print(f'wrote {output_json}')

if __name__ == '__main__':
    main()
