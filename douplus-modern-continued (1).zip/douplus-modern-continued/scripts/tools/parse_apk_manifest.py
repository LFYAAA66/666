#!/usr/bin/env python3
"""简易 AndroidManifest.xml 二进制解析器：提取 package/version/sdk/application。"""
import struct, sys, zipfile, json
RES_STRING_POOL_TYPE=0x0001
RES_XML_START_ELEMENT_TYPE=0x0102

def u16(b,o): return struct.unpack_from('<H', b, o)[0]
def u32(b,o): return struct.unpack_from('<I', b, o)[0]
def decode_len16(buf, off):
    val = struct.unpack_from('<H', buf, off)[0]
    if val & 0x8000:
        return (((val & 0x7FFF) << 16) | struct.unpack_from('<H', buf, off+2)[0]), 4
    return val, 2

def main(apk_path: str):
    with zipfile.ZipFile(apk_path) as zf:
        data = zf.read('AndroidManifest.xml')
    pos = 8
    strings=[]
    manifest={}; uses_sdk={}; application={}
    while pos < len(data):
        ctype=u16(data,pos); hdr=u16(data,pos+2); size=u32(data,pos+4)
        if ctype == RES_STRING_POOL_TYPE:
            count=u32(data,pos+8); start=u32(data,pos+20)
            offs=[u32(data,pos+hdr+i*4) for i in range(count)]
            base=pos+start
            strings=[]
            for off in offs:
                l,skip=decode_len16(data, base+off)
                strings.append(data[base+off+skip:base+off+skip+l*2].decode('utf-16le','replace'))
        elif ctype == RES_XML_START_ELEMENT_TYPE:
            name=u32(data,pos+20)
            tag=strings[name]
            attrStart=u16(data,pos+24); attrSize=u16(data,pos+26); attrCount=u16(data,pos+28)
            attrs={}
            attrs_off=pos+16+attrStart
            for i in range(attrCount):
                ao=attrs_off+i*attrSize
                aname=u32(data,ao+4); araw=u32(data,ao+8); dtype=data[ao+15]; val=u32(data,ao+16)
                key=strings[aname]
                raw=strings[araw] if 0 <= araw < len(strings) else None
                if dtype == 0x03 and 0 <= val < len(strings):
                    attrs[key]=strings[val]
                elif raw is not None:
                    attrs[key]=raw
                elif dtype == 0x10:
                    attrs[key]=val
                elif dtype == 0x12:
                    attrs[key]=bool(val)
                else:
                    attrs[key]=f'type=0x{dtype:02x},data=0x{val:x}'
            if tag == 'manifest': manifest=attrs
            elif tag == 'uses-sdk': uses_sdk=attrs
            elif tag == 'application': application=attrs
        pos += size
    print(json.dumps({'manifest': manifest, 'uses-sdk': uses_sdk, 'application': application}, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    if len(sys.argv) != 2:
        print('用法: parse_apk_manifest.py path/to/base.apk', file=sys.stderr)
        sys.exit(1)
    main(sys.argv[1])
