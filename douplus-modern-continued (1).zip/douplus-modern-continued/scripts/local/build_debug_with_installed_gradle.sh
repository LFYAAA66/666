
#!/usr/bin/env bash
set -euo pipefail
if ! command -v gradle >/dev/null 2>&1; then
  echo "未检测到 gradle。请先安装 Android Studio，或者先用 GitHub Actions 自动打包。"
  exit 1
fi
gradle :app:assembleDebug --stacktrace
