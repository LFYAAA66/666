
if (-not (Get-Command gradle -ErrorAction SilentlyContinue)) {
  Write-Host "未检测到 gradle。请先安装 Android Studio，或者先用 GitHub Actions 自动打包。"
  exit 1
}
gradle :app:assembleDebug --stacktrace
