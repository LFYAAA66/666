package com.example.douplus.app

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.douplus.app.databinding.ActivityWardBinding

class WardActivity : AppCompatActivity() {
    private lateinit var binding: ActivityWardBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityWardBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.topBar.setNavigationOnClickListener { finish() }
        binding.summaryCount.text = "共 ${UiSampleData.wardItems.size} 条插眼"
        renderWardItems()
    }

    private fun renderWardItems() {
        val inflater = layoutInflater
        UiSampleData.wardItems.forEach { item ->
            val view = inflater.inflate(R.layout.item_ward_card, binding.wardContainer, false)
            val vb = com.example.douplus.app.databinding.ItemWardCardBinding.bind(view)
            vb.typeChip.text = item.type
            vb.objectId.text = item.objectId
            vb.sourcePage.text = item.source
            vb.remark.text = item.remark
            vb.category.text = item.category
            vb.time.text = item.time
            binding.wardContainer.addView(view)
        }
    }
}
