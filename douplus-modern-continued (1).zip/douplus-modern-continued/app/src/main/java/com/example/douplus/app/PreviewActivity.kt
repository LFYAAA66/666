package com.example.douplus.app

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.douplus.app.databinding.ActivityPreviewBinding

class PreviewActivity : AppCompatActivity() {
    private lateinit var binding: ActivityPreviewBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPreviewBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.topBar.setNavigationOnClickListener { finish() }

        when (intent.getStringExtra(EXTRA_MODE)) {
            MODE_COMMENT -> bindCommentPreview()
            else -> bindVideoPreview()
        }
    }

    private fun bindVideoPreview() {
        binding.pageTitle.text = "视频信息面板预览"
        binding.pageDesc.text = "尽量复刻旧模块的视频信息弹层观感，实际注入位置仍取决于当前宿主版本 Hook 点。"
        binding.primaryTitle.text = "发布时间"
        binding.primaryValue.text = "2026-03-31 14:20:36"
        binding.secondaryTitle.text = "发布地区"
        binding.secondaryValue.text = "江苏·苏州"
        binding.metricsTitle.text = "互动数据"
        binding.metricsValue.text = "赞 1.2w  评论 728  收藏 460  分享 331"
        binding.footerTitle.text = "可用动作"
        binding.footerValue.text = "复制文案 / 封面图片 / 音乐信息 / 插眼 / 保存图片"
    }

    private fun bindCommentPreview() {
        binding.pageTitle.text = "评论增强预览"
        binding.pageDesc.text = "这里展示评论时间、过滤、长按菜单和播放联动的预期样式。"
        binding.primaryTitle.text = "评论时间"
        binding.primaryValue.text = "2026-03-31 13:08:12"
        binding.secondaryTitle.text = "评论模板"
        binding.secondaryValue.text = "${'$'}{originalText} · ${'$'}{time}"
        binding.metricsTitle.text = "长按菜单"
        binding.metricsValue.text = "评论时间 / 保存语音 / 保存图片 / 图片信息 / 插眼 / 插眼列表"
        binding.footerTitle.text = "联动行为"
        binding.footerValue.text = "打开评论自动暂停视频，关闭评论恢复播放"
    }

    companion object {
        const val EXTRA_MODE = "mode"
        const val MODE_VIDEO = "video"
        const val MODE_COMMENT = "comment"
    }
}
