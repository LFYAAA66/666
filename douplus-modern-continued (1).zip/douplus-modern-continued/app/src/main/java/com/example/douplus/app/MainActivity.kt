package com.example.douplus.app

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.douplus.app.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var repository: AssetDataRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        repository = AssetDataRepository(this)

        bindHostOverview()
        bindClicks()
    }

    private fun bindHostOverview() {
        val host = repository.loadHostInfo()
        val support = repository.loadSupportOverview()
        binding.hostVersionValue.text = "${host.versionName} (${host.versionCode})"
        binding.hostPackageValue.text = host.packageName
        binding.frameworkValue.text = support.moduleLine
        binding.buildStateValue.text = support.features.joinToString(" / ") { "${it.feature}:${it.status}" }
    }

    private fun bindClicks() {
        binding.btnOpenSettings.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
        binding.btnWardSystem.setOnClickListener { startActivity(Intent(this, WardActivity::class.java)) }
        binding.btnBackup.setOnClickListener { startActivity(Intent(this, BackupActivity::class.java)) }
        binding.btnDiagnostics.setOnClickListener { startActivity(Intent(this, DiagnosticsActivity::class.java)) }
        binding.btnVideoPanel.setOnClickListener {
            startActivity(Intent(this, PreviewActivity::class.java).putExtra(PreviewActivity.EXTRA_MODE, PreviewActivity.MODE_VIDEO))
        }
        binding.btnCommentPanel.setOnClickListener {
            startActivity(Intent(this, PreviewActivity::class.java).putExtra(PreviewActivity.EXTRA_MODE, PreviewActivity.MODE_COMMENT))
        }
        binding.btnBuildGuide.setOnClickListener {
            showInfo(
                title = "小白打包说明",
                message = "仓库里已经带 GitHub Actions 自动打包与本地脚本。当前工程默认绑定抖音 38.2.0 / 380201。你直接上传到 GitHub 跑 Actions 即可下载 APK。"
            )
        }
        binding.btnHostAnalysis.setOnClickListener {
            val host = repository.loadHostInfo()
            val reference = repository.loadReferenceModuleSummary()
            showInfo(
                title = "当前宿主与参考模块",
                message = buildString {
                    append("当前宿主: ${host.packageName} ${host.versionName} (${host.versionCode})\n")
                    append("Application: ${host.applicationName}\n")
                    append("参考模块入口: ${reference.xposedInit}\n")
                    append("参考模块 DEX: ${reference.dexCount}，layout: ${reference.layoutCount}\n\n")
                    append(host.notes.joinToString("\n"))
                }
            )
        }
        binding.btnRefreshHint.setOnClickListener {
            showInfo("页面刷新", "宿主刷新链已经预留接口，真实刷新点仍需继续命中当前抖音 38.2.0 的候选方法。")
        }
    }

    private fun showInfo(title: String, message: String) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("知道了", null)
            .show()
    }
}
