package com.example.douplus.app

object UiSampleData {
    val settingGroups = listOf(
        SettingGroup(
            title = "基础设置",
            items = listOf(
                SettingItem("video.show.time", "显示发布时间", "视频信息面板显示精确发布时间", true),
                SettingItem("video.show.location", "显示发布地", "在可读取时展示发布地区", true),
                SettingItem("remote.rules.enabled", "远程规则更新", "使用公开 JSON 规则，不是授权系统", false)
            )
        ),
        SettingGroup(
            title = "评论增强",
            items = listOf(
                SettingItem("comment.copy.remove.at", "复制评论去除@", "复制时剔除艾特前缀", true),
                SettingItem("comment.pause.video", "打开评论自动暂停视频", "关闭评论后恢复播放", true),
                SettingItem("comment.show.time", "显示评论具体时间", "评论时间模板后续继续接入", true)
            )
        ),
        SettingGroup(
            title = "备份与恢复",
            items = listOf(
                SettingItem("backup.auto.enabled", "自动备份", "配置变化后可自动触发备份", false)
            )
        )
    )

    val wardItems = listOf(
        WardPreview("视频", "72941520001", "首页推荐流", "这个视频后续想观察评论区走向", "摸鱼素材", "今天 14:20"),
        WardPreview("评论", "cmt_882731", "评论弹层", "这条评论需要单独保存与回看", "高互动评论", "今天 13:02"),
        WardPreview("用户", "uid_18273", "用户主页", "这个用户发的视频方向比较稳定", "创作者观察", "昨天 21:47")
    )

    val backupSteps = listOf(
        "导出模块配置",
        "导出插眼数据库",
        "写入 ZIP 清单",
        "校验 hash 与 schemaVersion",
        "可选上传到 WebDAV"
    )
}

data class SettingGroup(val title: String, val items: List<SettingItem>)
data class SettingItem(val key: String, val title: String, val summary: String, val defaultEnabled: Boolean)
data class WardPreview(
    val type: String,
    val objectId: String,
    val source: String,
    val remark: String,
    val category: String,
    val time: String
)
data class DiagnosticPreview(val feature: String, val status: String, val detail: String)
