package com.example.douplus.app

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.douplus.app.databinding.ActivityDiagnosticsBinding
import com.example.douplus.app.databinding.ItemDiagnosticCardBinding

class DiagnosticsActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDiagnosticsBinding
    private lateinit var repository: AssetDataRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDiagnosticsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        repository = AssetDataRepository(this)

        binding.topBar.setNavigationOnClickListener { finish() }
        renderDiagnostics(repository.loadSupportOverview().features)
    }

    private fun renderDiagnostics(items: List<DiagnosticPreview>) {
        val inflater = layoutInflater
        binding.cardContainer.removeAllViews()
        items.forEach { item ->
            val view = inflater.inflate(R.layout.item_diagnostic_card, binding.cardContainer, false)
            val vb = ItemDiagnosticCardBinding.bind(view)
            vb.featureName.text = item.feature
            vb.status.text = item.status
            vb.detail.text = item.detail
            binding.cardContainer.addView(view)
        }
    }
}
