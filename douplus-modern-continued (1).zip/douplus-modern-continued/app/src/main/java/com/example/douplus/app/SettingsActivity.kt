package com.example.douplus.app

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.douplus.app.databinding.ActivitySettingsBinding
import com.example.douplus.app.databinding.ItemSettingGroupCardBinding
import com.example.douplus.app.databinding.ItemSettingSwitchRowBinding
import com.example.douplus.data.config.local.AppSettingsStore
import kotlinx.coroutines.launch

class SettingsActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySettingsBinding
    private lateinit var store: AppSettingsStore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        store = AppSettingsStore(this)

        binding.topBar.setNavigationOnClickListener { finish() }

        lifecycleScope.launch {
            renderGroups(store.currentSnapshot())
        }
    }

    private fun renderGroups(snapshot: com.example.douplus.data.config.model.FeatureSettingsSnapshot) {
        binding.groupContainer.removeAllViews()
        val inflater = layoutInflater
        UiSampleData.settingGroups.forEach { group ->
            val card = inflater.inflate(R.layout.item_setting_group_card, binding.groupContainer, false)
            val cardBinding = ItemSettingGroupCardBinding.bind(card)
            cardBinding.groupTitle.text = group.title
            group.items.forEach { item ->
                val row = inflater.inflate(R.layout.item_setting_switch_row, cardBinding.itemContainer, false)
                val rowBinding = ItemSettingSwitchRowBinding.bind(row)
                rowBinding.title.text = item.title
                rowBinding.summary.text = item.summary
                val current = store.currentEnabledForUiKey(snapshot, item.key, item.defaultEnabled)
                rowBinding.toggle.isChecked = current
                rowBinding.status.text = if (current) "已启用" else "已关闭"
                rowBinding.toggle.setOnCheckedChangeListener { _, isChecked ->
                    rowBinding.status.text = if (isChecked) "已启用" else "已关闭"
                    lifecycleScope.launch { store.updateBooleanByUiKey(item.key, isChecked) }
                }
                cardBinding.itemContainer.addView(row)
            }
            binding.groupContainer.addView(card)
        }
    }
}
