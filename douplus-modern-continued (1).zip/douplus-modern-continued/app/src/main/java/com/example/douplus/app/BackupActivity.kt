package com.example.douplus.app

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.douplus.app.databinding.ActivityBackupBinding

class BackupActivity : AppCompatActivity() {
    private lateinit var binding: ActivityBackupBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBackupBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.topBar.setNavigationOnClickListener { finish() }
        binding.btnExport.setOnClickListener { toast("这里后续接本地 ZIP 导出") }
        binding.btnImport.setOnClickListener { toast("这里后续接 ZIP 导入与恢复校验") }
        binding.btnWebDav.setOnClickListener { toast("这里后续接 WebDAV 连通测试与备份") }

        val inflater = layoutInflater
        UiSampleData.backupSteps.forEachIndexed { index, step ->
            val item = inflater.inflate(R.layout.item_backup_step, binding.stepContainer, false)
            val vb = com.example.douplus.app.databinding.ItemBackupStepBinding.bind(item)
            vb.stepIndex.text = (index + 1).toString()
            vb.stepTitle.text = step
            binding.stepContainer.addView(item)
        }
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
