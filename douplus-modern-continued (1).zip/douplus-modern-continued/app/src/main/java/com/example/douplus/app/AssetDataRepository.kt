package com.example.douplus.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class HostInfo(
    val packageName: String,
    val versionName: String,
    val versionCode: Long,
    val targetSdkVersion: Int,
    val minSdkVersion: Int,
    val applicationName: String,
    val notes: List<String>
)

data class SupportOverview(
    val moduleLine: String,
    val features: List<DiagnosticPreview>
)

data class ReferenceModuleSummary(
    val xposedInit: String,
    val dexCount: Int,
    val layoutCount: Int,
    val drawableXmlCount: Int,
    val topPackages: List<Pair<String, Int>>
)

class AssetDataRepository(private val context: Context) {
    private fun readAsset(name: String): String =
        context.assets.open(name).bufferedReader(Charsets.UTF_8).use { it.readText() }

    fun loadHostInfo(): HostInfo {
        val obj = JSONObject(readAsset("current_host.json"))
        val notesArray = obj.optJSONArray("notes") ?: JSONArray()
        val notes = buildList {
            for (i in 0 until notesArray.length()) add(notesArray.optString(i))
        }
        return HostInfo(
            packageName = obj.optString("packageName"),
            versionName = obj.optString("versionName"),
            versionCode = obj.optLong("versionCode"),
            targetSdkVersion = obj.optInt("targetSdkVersion"),
            minSdkVersion = obj.optInt("minSdkVersion"),
            applicationName = obj.optString("applicationName"),
            notes = notes
        )
    }

    fun loadSupportOverview(): SupportOverview {
        val obj = JSONObject(readAsset("support_overview.json"))
        val arr = obj.optJSONArray("features") ?: JSONArray()
        val items = buildList {
            for (i in 0 until arr.length()) {
                val item = arr.getJSONObject(i)
                add(
                    DiagnosticPreview(
                        feature = item.optString("feature"),
                        status = item.optString("status"),
                        detail = item.optString("detail")
                    )
                )
            }
        }
        return SupportOverview(
            moduleLine = obj.optString("moduleLine"),
            features = items
        )
    }

    fun loadReferenceModuleSummary(): ReferenceModuleSummary {
        val obj = JSONObject(readAsset("reference_module_summary.json"))
        val topPackagesJson = obj.optJSONArray("top_packages") ?: JSONArray()
        val topPackages = buildList {
            for (i in 0 until topPackagesJson.length()) {
                val pair = topPackagesJson.getJSONArray(i)
                add(pair.getString(0) to pair.getInt(1))
            }
        }
        return ReferenceModuleSummary(
            xposedInit = obj.optString("xposed_init"),
            dexCount = obj.optInt("dex_count"),
            layoutCount = obj.optInt("layout_count"),
            drawableXmlCount = obj.optInt("drawable_xml_count"),
            topPackages = topPackages
        )
    }
}
