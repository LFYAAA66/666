package com.example.douplus.feature.settings

import com.example.douplus.adapter.report.AdaptationReport
import com.example.douplus.adapter.targets.SettingsEntryTargets
import com.example.douplus.core.logging.LogCenter
import com.example.douplus.core.reflection.HostReflectionResolver
import com.example.douplus.core.safety.HookIsolationRunner
import com.example.douplus.data.config.repository.ConfigRepository
import com.example.douplus.feature.settings.hook.SettingsBottomMenuHooker
import com.example.douplus.feature.settings.hook.SettingsMenuHooker
import com.example.douplus.hookapi.*

class SettingsRouteBridge {
    fun openModuleSettings() {
        // TODO("待宿主定位: 路由到模块设置页或弹出模块面板")
    }
}

class HostRefreshController {
    fun requestRefresh() {
        // TODO("待宿主定位: 刷新当前页面")
    }
}

class SettingsEntryFeature(
    private val logCenter: LogCenter,
    private val configRepository: ConfigRepository,
) : FeatureHookModule {
    override val featureName = "settings"
    override val supportedPackages = setOf(
        "com.ss.android.ugc.aweme",
        "com.ss.android.ugc.aweme.mobile",
        "com.ss.android.ugc.aweme.lite",
        "com.ss.android.ugc.live",
        "com.ss.android.ugc.livelite",
    )
    override fun supportsVersion(versionCode: Long): Boolean = true

    override fun install(hostSession: HostSession, targets: HookTargetSet, report: AdaptationReport): HookInstallResult {
        val typed = targets as? SettingsEntryTargets ?: return HookInstallResult(false, "wrong target type")
        val bridge = hostSession.hookBridge ?: return HookInstallResult(false, "missing hook bridge")
        val runner = HookIsolationRunner(logCenter)
        val classLoader = hostSession.descriptor.classLoader
        var installedCount = 0

        val topResolved = HostReflectionResolver.resolveMethod(classLoader, typed.topMenuBuildMethod)
        if (topResolved != null) {
            if (runner.guarded(featureName, "SettingsEntryFeature", "topMenu", report) {
                    bridge.installMethodHook(topResolved.method, SettingsMenuHooker::class.java)
                    logCenter.i("Installed settings top menu hook: ${HostReflectionResolver.dumpMethodSignature(topResolved.method)}")
                }) installedCount++
        } else if (typed.topMenuBuildMethod != null) {
            report.recordFailure(featureName, "SettingsEntryFeature", "topMenu", "Failed to resolve top menu method")
        }

        val bottomResolved = HostReflectionResolver.resolveMethod(classLoader, typed.bottomMenuBuildMethod)
        if (bottomResolved != null) {
            if (runner.guarded(featureName, "SettingsEntryFeature", "bottomMenu", report) {
                    bridge.installMethodHook(bottomResolved.method, SettingsBottomMenuHooker::class.java)
                    logCenter.i("Installed settings bottom menu hook: ${HostReflectionResolver.dumpMethodSignature(bottomResolved.method)}")
                }) installedCount++
        } else if (typed.bottomMenuBuildMethod != null) {
            report.recordFailure(featureName, "SettingsEntryFeature", "bottomMenu", "Failed to resolve bottom menu method")
        }

        return HookInstallResult(installedCount > 0, if (installedCount > 0) "settings installed" else "no available resolved injection point", partial = installedCount == 1)
    }
}
