package com.example.douplus.feature.settings.hook

import com.example.douplus.core.android.HostUiTools
import io.github.libxposed.api.XposedInterface

class SettingsMenuHooker : XposedInterface.Hooker {
    companion object {
        @JvmStatic
        fun before(callback: XposedInterface.BeforeHookCallback): Long = System.nanoTime()

        @JvmStatic
        fun after(callback: XposedInterface.AfterHookCallback, startNs: Long) {
            val target = callback.thisObject ?: callback.result
            HostUiTools.addModuleEntryBadge(target, "模块设置", "douplus_settings_entry")
        }
    }
}

class SettingsBottomMenuHooker : XposedInterface.Hooker {
    companion object {
        @JvmStatic
        fun before(callback: XposedInterface.BeforeHookCallback) = Unit

        @JvmStatic
        fun after(callback: XposedInterface.AfterHookCallback) {
            val target = callback.thisObject ?: callback.result
            HostUiTools.bindLongPressActions(target, "抖+快捷入口", listOf("模块设置", "插眼列表", "适配诊断"))
        }
    }
}
