package com.example.douplus.adapter.matcher

import com.example.douplus.hookapi.MethodRef

class SignatureMatcher {
    fun score(methodRef: MethodRef, ownerName: String?, methodName: String?, paramCount: Int): Int {
        var score = 0
        if (methodRef.ownerHint == ownerName) score += 40
        if (methodRef.methodNameHint == methodName) score += 30
        if (methodRef.paramCount == paramCount) score += 20
        return score
    }
}
