package com.example.douplus.adapter.preset

import com.example.douplus.adapter.targets.*
import com.example.douplus.hookapi.FieldRef
import com.example.douplus.hookapi.MethodRef

object CurrentHostPresets {
    const val AWEME = "com.ss.android.ugc.aweme"
    const val AWEME_VERSION_CODE = 380201L
    const val AWEME_VERSION_LABEL = "38.2.0 / 380201"

    fun matchAweme380201(packageName: String, versionCode: Long): Boolean {
        return packageName == AWEME && versionCode == AWEME_VERSION_CODE
    }

    fun settingsTargets(): SettingsEntryTargets = SettingsEntryTargets(
        topMenuBuildMethod = MethodRef("com.ss.android.ugc.aweme.comment.ui.common.CommentCommonSettingsDialog", "initItemView", 0, "void"),
        bottomMenuBuildMethod = MethodRef("com.ss.android.ugc.aweme.im.business.menusettingpage.MenuEducationFragment", "onViewCreated", 2, "void"),
        routeDispatchMethod = MethodRef("com.ss.android.ugc.aweme.app.host.AwemeHostApplication", "onCreate", 0, "void"),
        refreshMethod = null,
        versionRangeLabel = AWEME_VERSION_LABEL,
        confidenceScore = 44,
    )

    fun videoTargets(): VideoTargets = VideoTargets(
        videoInfoBindMethod = MethodRef("com.ss.android.ugc.aweme.commentfeed.viewholder.OVideoPlayerModel", "onBind", 2, "void"),
        videoMenuBuildMethod = MethodRef("com.bytedance.ies.ugc.aweme.photos.detail.flow.page.comment.CommentListPresenter", "onBind", 1, "void"),
        playerContainerField = FieldRef("com.ss.android.ugc.aweme.commentfeed.viewholder.OVideoPlayerModel", "itemView", "android.view.View"),
        progressBarField = null,
        musicControlField = null,
        versionRangeLabel = AWEME_VERSION_LABEL,
        confidenceScore = 28,
    )

    fun commentTargets(): CommentTargets = CommentTargets(
        commentBindMethod = MethodRef("com.ss.android.ugc.aweme.comment.adapter.CommentReplyButtonViewHolder", "onBind", 2, "void"),
        commentMenuBuildMethod = MethodRef("com.ss.android.ugc.aweme.comment.ui.diggbury.DiggBuryViewDelegate", "onBind", 1, "void"),
        commentTimeField = FieldRef("com.ss.android.ugc.aweme.comment.adapter.CommentReplyButtonViewHolder", "createTime", "long"),
        commentOpenCloseMethod = MethodRef("com.bytedance.ies.ugc.aweme.photos.detail.flow.page.comment.CommentListPresenter", "onBind", 1, "void"),
        versionRangeLabel = AWEME_VERSION_LABEL,
        confidenceScore = 32,
    )

    fun wardTargets(): WardTargets = WardTargets(
        contextExtractMethod = MethodRef("com.bytedance.ies.ugc.aweme.photos.detail.flow.page.comment.CommentListPresenter", "onBind", 1, "void"),
        entryInjectMethod = MethodRef("com.ss.android.ugc.aweme.comment.ui.common.CommentCommonSettingsDialog", "initItemView", 0, "void"),
        versionRangeLabel = AWEME_VERSION_LABEL,
        confidenceScore = 22,
    )

    fun chatTargets(): ChatTargets = ChatTargets(
        messageBindMethod = MethodRef("待宿主定位", "待宿主定位", 2, "void"),
        sendPanelMethod = MethodRef("待宿主定位", "待宿主定位", 1, "void"),
        versionRangeLabel = AWEME_VERSION_LABEL,
        confidenceScore = 5,
    )

    fun fallbackSettingsTargets(): SettingsEntryTargets = SettingsEntryTargets(
        topMenuBuildMethod = MethodRef("待宿主定位", "待宿主定位", 0, "void"),
        bottomMenuBuildMethod = MethodRef("待宿主定位", "待宿主定位", 0, "void"),
        routeDispatchMethod = null,
        refreshMethod = null,
        confidenceScore = 10,
    )

    fun fallbackVideoTargets(): VideoTargets = VideoTargets(
        videoInfoBindMethod = MethodRef("待宿主定位", "待宿主定位", 2, "void"),
        videoMenuBuildMethod = MethodRef("待宿主定位", "待宿主定位", 1, "void"),
        playerContainerField = FieldRef("待宿主定位", "待宿主定位", "android.view.View"),
        progressBarField = null,
        musicControlField = null,
        confidenceScore = 8,
    )

    fun fallbackCommentTargets(): CommentTargets = CommentTargets(
        commentBindMethod = MethodRef("待宿主定位", "待宿主定位", 2, "void"),
        commentMenuBuildMethod = MethodRef("待宿主定位", "待宿主定位", 1, "void"),
        commentTimeField = FieldRef("待宿主定位", "待宿主定位", "long"),
        commentOpenCloseMethod = MethodRef("待宿主定位", "待宿主定位", 1, "void"),
        confidenceScore = 8,
    )
}
