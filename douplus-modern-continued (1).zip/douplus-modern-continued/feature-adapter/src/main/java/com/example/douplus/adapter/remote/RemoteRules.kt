package com.example.douplus.adapter.remote

import kotlinx.serialization.Serializable

@Serializable
data class ResolverHint(
    val type: String,
    val ownerHint: String? = null,
    val methodNameHint: String? = null,
    val fieldNameHint: String? = null,
    val paramCount: Int? = null,
    val returnTypeHint: String? = null,
)

@Serializable
data class PackageRules(
    val featureRules: Map<String, List<ResolverHint>> = emptyMap()
)

@Serializable
data class RemoteRulePayload(
    val schemaVersion: Int = 1,
    val ruleVersion: String,
    val generatedAt: Long,
    val packages: Map<String, Map<String, PackageRules>> = emptyMap(),
    val sha256: String = "",
)

interface RemoteRuleSource {
    suspend fun fetch(): RemoteRulePayload?
}

class CachedRuleStore {
    private val cache = linkedMapOf<String, RemoteRulePayload>()

    fun put(key: String, payload: RemoteRulePayload) {
        cache[key] = payload
    }

    fun get(key: String): RemoteRulePayload? = cache[key]
}
