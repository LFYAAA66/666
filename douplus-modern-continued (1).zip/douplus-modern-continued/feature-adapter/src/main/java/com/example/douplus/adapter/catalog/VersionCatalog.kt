package com.example.douplus.adapter.catalog

class VersionCatalog {
    fun labelFor(packageName: String, versionCode: Long): String = "$packageName@$versionCode"
}
