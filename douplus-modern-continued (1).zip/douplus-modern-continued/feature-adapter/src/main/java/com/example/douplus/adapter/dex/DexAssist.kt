package com.example.douplus.adapter.dex

import com.example.douplus.core.logging.LogCenter

/**
 * Modern API 里的 parseDex / deoptimize 只能集中在适配层。
 * 当前工程只保留门面，不做具体宿主实现。
 */
class DexAssist(private val logCenter: LogCenter) {
    fun explainUnavailable(): String {
        logCenter.i("DexAssist placeholder invoked")
        return "Dex-based resolution is pending host-specific implementation"
    }
}
