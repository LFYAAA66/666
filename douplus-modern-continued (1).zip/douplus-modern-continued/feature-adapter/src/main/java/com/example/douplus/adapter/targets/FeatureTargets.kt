package com.example.douplus.adapter.targets

import com.example.douplus.hookapi.*

data class SettingsEntryTargets(
    val topMenuBuildMethod: MethodRef? = null,
    val bottomMenuBuildMethod: MethodRef? = null,
    val routeDispatchMethod: MethodRef? = null,
    val refreshMethod: MethodRef? = null,
    override val versionRangeLabel: String = "all",
    override val confidenceScore: Int = 30,
    override val isOptional: Boolean = false,
    override val degradeLevel: DegradeLevel = DegradeLevel.PARTIAL,
) : HookTargetSet {
    override val featureName: String = "settings"
}

data class VideoTargets(
    val videoInfoBindMethod: MethodRef? = null,
    val videoMenuBuildMethod: MethodRef? = null,
    val playerContainerField: FieldRef? = null,
    val progressBarField: FieldRef? = null,
    val musicControlField: FieldRef? = null,
    override val versionRangeLabel: String = "all",
    override val confidenceScore: Int = 20,
    override val isOptional: Boolean = false,
    override val degradeLevel: DegradeLevel = DegradeLevel.PARTIAL,
) : HookTargetSet {
    override val featureName: String = "video"
}

data class CommentTargets(
    val commentBindMethod: MethodRef? = null,
    val commentMenuBuildMethod: MethodRef? = null,
    val commentTimeField: FieldRef? = null,
    val commentOpenCloseMethod: MethodRef? = null,
    override val versionRangeLabel: String = "all",
    override val confidenceScore: Int = 20,
    override val isOptional: Boolean = false,
    override val degradeLevel: DegradeLevel = DegradeLevel.PARTIAL,
) : HookTargetSet {
    override val featureName: String = "comment"
}

data class WardTargets(
    val contextExtractMethod: MethodRef? = null,
    val entryInjectMethod: MethodRef? = null,
    override val versionRangeLabel: String = "all",
    override val confidenceScore: Int = 15,
    override val isOptional: Boolean = true,
    override val degradeLevel: DegradeLevel = DegradeLevel.PARTIAL,
) : HookTargetSet {
    override val featureName: String = "ward"
}

data class ChatTargets(
    val messageBindMethod: MethodRef? = null,
    val sendPanelMethod: MethodRef? = null,
    override val versionRangeLabel: String = "all",
    override val confidenceScore: Int = 15,
    override val isOptional: Boolean = true,
    override val degradeLevel: DegradeLevel = DegradeLevel.PARTIAL,
) : HookTargetSet {
    override val featureName: String = "chat"
}
