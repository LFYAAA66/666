package com.example.douplus.adapter.resolver.impl

import com.example.douplus.adapter.preset.CurrentHostPresets
import com.example.douplus.adapter.report.AdaptationReport
import com.example.douplus.adapter.resolver.HookTargetResolver
import com.example.douplus.adapter.targets.*
import com.example.douplus.core.logging.LogCenter
import com.example.douplus.hookapi.HostDescriptor

class SettingsEntryResolver(private val logCenter: LogCenter) : HookTargetResolver<SettingsEntryTargets> {
    override val featureName = "settings"
    override val resolverName = "SettingsEntryResolver"
    override fun supports(host: HostDescriptor): Boolean = host.packageName.startsWith("com.ss.android.ugc.aweme")
    override fun resolve(host: HostDescriptor, report: AdaptationReport): SettingsEntryTargets {
        logCenter.i("Resolve settings targets for ${host.packageName} ${host.versionCode}")
        return if (CurrentHostPresets.matchAweme380201(host.packageName, host.versionCode)) CurrentHostPresets.settingsTargets() else CurrentHostPresets.fallbackSettingsTargets()
    }
}

class VideoResolver(private val logCenter: LogCenter) : HookTargetResolver<VideoTargets> {
    override val featureName = "video"
    override val resolverName = "VideoResolver"
    override fun supports(host: HostDescriptor): Boolean = host.packageName.startsWith("com.ss.android.ugc.aweme")
    override fun resolve(host: HostDescriptor, report: AdaptationReport): VideoTargets {
        logCenter.i("Resolve video targets for ${host.packageName} ${host.versionCode}")
        return if (CurrentHostPresets.matchAweme380201(host.packageName, host.versionCode)) CurrentHostPresets.videoTargets() else CurrentHostPresets.fallbackVideoTargets()
    }
}

class CommentResolver(private val logCenter: LogCenter) : HookTargetResolver<CommentTargets> {
    override val featureName = "comment"
    override val resolverName = "CommentResolver"
    override fun supports(host: HostDescriptor): Boolean = host.packageName.startsWith("com.ss.android.ugc.aweme")
    override fun resolve(host: HostDescriptor, report: AdaptationReport): CommentTargets {
        logCenter.i("Resolve comment targets for ${host.packageName} ${host.versionCode}")
        return if (CurrentHostPresets.matchAweme380201(host.packageName, host.versionCode)) CurrentHostPresets.commentTargets() else CurrentHostPresets.fallbackCommentTargets()
    }
}

class WardEntryResolver(private val logCenter: LogCenter) : HookTargetResolver<WardTargets> {
    override val featureName = "ward"
    override val resolverName = "WardEntryResolver"
    override fun supports(host: HostDescriptor): Boolean = host.packageName.startsWith("com.ss.android.ugc.aweme")
    override fun resolve(host: HostDescriptor, report: AdaptationReport): WardTargets {
        logCenter.i("Resolve ward targets for ${host.packageName} ${host.versionCode}")
        return if (CurrentHostPresets.matchAweme380201(host.packageName, host.versionCode)) CurrentHostPresets.wardTargets() else CurrentHostPresets.wardTargets().copy(versionRangeLabel = "all")
    }
}

class ChatResolver(private val logCenter: LogCenter) : HookTargetResolver<ChatTargets> {
    override val featureName = "chat"
    override val resolverName = "ChatResolver"
    override fun supports(host: HostDescriptor): Boolean = host.packageName.startsWith("com.ss.android.ugc.aweme")
    override fun resolve(host: HostDescriptor, report: AdaptationReport): ChatTargets {
        logCenter.i("Resolve chat targets for ${host.packageName} ${host.versionCode}")
        return CurrentHostPresets.chatTargets().copy(versionRangeLabel = if (CurrentHostPresets.matchAweme380201(host.packageName, host.versionCode)) CurrentHostPresets.AWEME_VERSION_LABEL else "all")
    }
}

class CommonUiResolver(private val logCenter: LogCenter) : HookTargetResolver<SettingsEntryTargets> {
    override val featureName = "common-ui"
    override val resolverName = "CommonUiResolver"
    override fun supports(host: HostDescriptor): Boolean = false
    override fun resolve(host: HostDescriptor, report: AdaptationReport): SettingsEntryTargets? = null
}
