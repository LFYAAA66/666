package com.example.douplus.adapter.engine

import com.example.douplus.adapter.registry.ResolverRegistry
import com.example.douplus.adapter.report.AdaptationReport
import com.example.douplus.core.logging.LogCenter
import com.example.douplus.hookapi.HostDescriptor
import com.example.douplus.hookapi.HookTargetSet

class AdapterEngine(
    private val logCenter: LogCenter,
) {
    private val registry = ResolverRegistry(logCenter)

    fun resolveAll(host: HostDescriptor, report: AdaptationReport): Map<String, HookTargetSet> {
        val out = linkedMapOf<String, HookTargetSet>()
        registry.allResolvers().forEach { resolver ->
            if (!resolver.supports(host)) return@forEach
            try {
                val target = resolver.resolve(host, report)
                if (target != null) {
                    out[resolver.featureName] = target
                } else {
                    report.recordFailure(resolver.featureName, resolver.resolverName, "resolve", "Resolver returned null")
                }
            } catch (t: Throwable) {
                report.recordFailure(resolver.featureName, resolver.resolverName, "resolve", "Resolver exception", t)
            }
        }
        return out
    }
}
