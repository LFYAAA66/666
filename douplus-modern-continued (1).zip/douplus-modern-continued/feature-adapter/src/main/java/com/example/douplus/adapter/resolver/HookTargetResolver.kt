package com.example.douplus.adapter.resolver

import com.example.douplus.adapter.report.AdaptationReport
import com.example.douplus.hookapi.HostDescriptor
import com.example.douplus.hookapi.HookTargetSet

interface HookTargetResolver<T : HookTargetSet> {
    val featureName: String
    val resolverName: String
    fun supports(host: HostDescriptor): Boolean
    fun resolve(host: HostDescriptor, report: AdaptationReport): T?
}
