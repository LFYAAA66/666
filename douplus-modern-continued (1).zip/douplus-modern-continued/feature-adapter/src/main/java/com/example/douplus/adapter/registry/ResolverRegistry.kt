package com.example.douplus.adapter.registry

import com.example.douplus.adapter.resolver.HookTargetResolver
import com.example.douplus.adapter.resolver.impl.*
import com.example.douplus.core.logging.LogCenter

class ResolverRegistry(logCenter: LogCenter) {
    private val resolvers: List<HookTargetResolver<*>> = listOf(
        SettingsEntryResolver(logCenter),
        VideoResolver(logCenter),
        CommentResolver(logCenter),
        WardEntryResolver(logCenter),
        ChatResolver(logCenter),
    )

    fun allResolvers(): List<HookTargetResolver<*>> = resolvers
}
