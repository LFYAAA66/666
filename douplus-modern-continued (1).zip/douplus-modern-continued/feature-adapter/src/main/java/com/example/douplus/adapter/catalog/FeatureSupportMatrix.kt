package com.example.douplus.adapter.catalog

enum class SupportState { SUCCESS, PARTIAL_SUCCESS, FAILED, PLACEHOLDER }

data class FeatureSupport(
    val featureName: String,
    val state: SupportState,
    val note: String
)

data class FeatureSupportMatrix(
    val hostPackage: String,
    val versionCode: Long,
    val supportedFeatures: List<FeatureSupport>
)
