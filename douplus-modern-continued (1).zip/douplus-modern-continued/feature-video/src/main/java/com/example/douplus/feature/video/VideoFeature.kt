package com.example.douplus.feature.video

import com.example.douplus.adapter.report.AdaptationReport
import com.example.douplus.adapter.targets.VideoTargets
import com.example.douplus.core.format.TimeFormatEngine
import com.example.douplus.core.logging.LogCenter
import com.example.douplus.core.reflection.HostReflectionResolver
import com.example.douplus.core.safety.HookIsolationRunner
import com.example.douplus.data.config.model.FeatureSettingsSnapshot
import com.example.douplus.data.config.repository.ConfigRepository
import com.example.douplus.feature.video.hook.VideoInfoPanelHooker
import com.example.douplus.feature.video.hook.VideoLongPressMenuHooker
import com.example.douplus.hookapi.*

data class VideoDisplayStyle(
    val showPublishTime: Boolean,
    val showPublishLocation: Boolean,
    val textSizeSp: Int,
    val textColorHex: String,
    val colorfulDisplay: Boolean,
)

class VideoDisplayPreferenceMapper {
    fun map(snapshot: FeatureSettingsSnapshot): VideoDisplayStyle = VideoDisplayStyle(
        showPublishTime = snapshot.videoShowPublishTime,
        showPublishLocation = snapshot.videoShowPublishLocation,
        textSizeSp = snapshot.videoTextSizeSp,
        textColorHex = snapshot.videoTextColorHex,
        colorfulDisplay = snapshot.videoColorfulDisplay,
    )
}

class VideoFilterEvaluator {
    fun shouldHide(desc: String?, likeCount: Long?, keywordRules: List<String>, minLike: Long?): Boolean {
        val keywordHit = keywordRules.any { rule -> !rule.isBlank() && desc?.contains(rule, ignoreCase = true) == true }
        val likeHit = minLike != null && (likeCount ?: 0L) < minLike
        return keywordHit || likeHit
    }
}

class VideoInfoPanelController(private val timeFormatEngine: TimeFormatEngine = TimeFormatEngine()) {
    fun buildSummary(publishTime: Long?, publishLocation: String?, desc: String?): String {
        val timeText = publishTime?.let { timeFormatEngine.format(it, "yyyy-MM-dd HH:mm:ss") } ?: "unknown"
        return listOfNotNull(timeText, publishLocation, desc).joinToString(" | ")
    }
}

class VideoProgressOverlayController
class MusicControlOffsetController
class VideoMenuContributor

class VideoFeature(
    private val logCenter: LogCenter,
    private val configRepository: ConfigRepository,
) : FeatureHookModule {
    override val featureName = "video"
    override val supportedPackages = setOf(
        "com.ss.android.ugc.aweme",
        "com.ss.android.ugc.aweme.mobile",
        "com.ss.android.ugc.aweme.lite",
    )
    override fun supportsVersion(versionCode: Long): Boolean = true

    override fun install(hostSession: HostSession, targets: HookTargetSet, report: AdaptationReport): HookInstallResult {
        val typed = targets as? VideoTargets ?: return HookInstallResult(false, "wrong target type")
        val bridge = hostSession.hookBridge ?: return HookInstallResult(false, "missing hook bridge")
        val classLoader = hostSession.descriptor.classLoader
        val runner = HookIsolationRunner(logCenter)
        var installed = 0

        val infoResolved = HostReflectionResolver.resolveMethod(classLoader, typed.videoInfoBindMethod)
        if (infoResolved != null) {
            if (runner.guarded(featureName, "VideoFeature", "videoInfoBindMethod", report) {
                    bridge.installMethodHook(infoResolved.method, VideoInfoPanelHooker::class.java)
                    logCenter.i("Installed video info hook: ${HostReflectionResolver.dumpMethodSignature(infoResolved.method)}")
                }) installed++
        } else if (typed.videoInfoBindMethod != null) {
            report.recordFailure(featureName, "VideoFeature", "videoInfoBindMethod", "Failed to resolve video info bind method")
        }

        val menuResolved = HostReflectionResolver.resolveMethod(classLoader, typed.videoMenuBuildMethod)
        if (menuResolved != null) {
            if (runner.guarded(featureName, "VideoFeature", "videoMenuBuildMethod", report) {
                    bridge.installMethodHook(menuResolved.method, VideoLongPressMenuHooker::class.java)
                    logCenter.i("Installed video menu hook: ${HostReflectionResolver.dumpMethodSignature(menuResolved.method)}")
                }) installed++
        } else if (typed.videoMenuBuildMethod != null) {
            report.recordFailure(featureName, "VideoFeature", "videoMenuBuildMethod", "Failed to resolve video menu method")
        }

        return HookInstallResult(installed > 0, if (installed > 0) "video installed" else "video core target missing", partial = installed == 1)
    }
}
