package com.example.douplus.feature.video.hook

import com.example.douplus.core.android.HostUiTools
import io.github.libxposed.api.XposedInterface

class VideoInfoPanelHooker : XposedInterface.Hooker {
    companion object {
        @JvmStatic
        fun before(callback: XposedInterface.BeforeHookCallback): Long = System.nanoTime()

        @JvmStatic
        fun after(callback: XposedInterface.AfterHookCallback, startNs: Long) {
            val target = callback.thisObject ?: callback.result
            HostUiTools.addModuleEntryBadge(target, "视频信息", "douplus_video_info_badge")
        }
    }
}

class VideoLongPressMenuHooker : XposedInterface.Hooker {
    companion object {
        @JvmStatic
        fun before(callback: XposedInterface.BeforeHookCallback) = Unit

        @JvmStatic
        fun after(callback: XposedInterface.AfterHookCallback) {
            val target = callback.thisObject ?: callback.result
            HostUiTools.bindLongPressActions(target, "抖+视频操作", listOf("视频信息", "插眼", "复制文案", "模块设置"))
        }
    }
}
