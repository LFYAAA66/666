package com.example.douplus.data.backup

import kotlinx.serialization.Serializable

@Serializable
data class BackupManifest(
    val schemaVersion: Int,
    val appVersion: String,
    val createdAt: Long,
    val sections: List<String>,
    val fileName: String? = null,
    val fileHash: String? = null,
)

@Serializable
data class WardExportItem(
    val id: Long,
    val objectType: String,
    val objectId: String,
    val hostPackage: String,
    val title: String? = null,
    val summary: String? = null,
    val remark: String? = null,
    val categoryId: Long? = null,
    val sourcePage: String? = null,
    val createdAt: Long,
    val updatedAt: Long,
    val extraJson: String? = null,
)

@Serializable
data class BackupBundle(
    val manifest: BackupManifest,
    val settingsJson: String,
    val wards: List<WardExportItem> = emptyList(),
)
