package com.example.douplus.data.backup

import com.example.douplus.core.json.JsonCodec
import java.io.File
import java.security.MessageDigest

class BackupEncryptor {
    fun protect(text: String): String = text
    fun unprotect(text: String): String = text
}

class BackupPackageWriter(
    private val jsonCodec: JsonCodec = JsonCodec(),
    private val encryptor: BackupEncryptor = BackupEncryptor(),
) {
    fun write(bundle: BackupBundle, targetFile: File): File {
        targetFile.parentFile?.mkdirs()
        targetFile.writeText(encryptor.protect(jsonCodec.encode(bundle)))
        return targetFile
    }

    fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val bytes = file.readBytes()
        return digest.digest(bytes).joinToString("") { "%02x".format(it) }
    }
}

class BackupPackageReader(
    private val jsonCodec: JsonCodec = JsonCodec(),
    private val encryptor: BackupEncryptor = BackupEncryptor(),
) {
    fun read(file: File): BackupBundle {
        return jsonCodec.decode(encryptor.unprotect(file.readText()))
    }
}

class RestoreValidator {
    fun validate(bundle: BackupBundle, expectedSchemaVersion: Int): Boolean {
        return bundle.manifest.schemaVersion == expectedSchemaVersion
    }
}

interface WebDavClientFacade {
    suspend fun testConnection(baseUrl: String, username: String?, passwordOrToken: String?): Boolean
    suspend fun upload(localFile: File, remoteDir: String): Boolean
    suspend fun download(remoteName: String, targetFile: File): Boolean
}

class NoopWebDavClientFacade : WebDavClientFacade {
    override suspend fun testConnection(baseUrl: String, username: String?, passwordOrToken: String?) = false
    override suspend fun upload(localFile: File, remoteDir: String) = false
    override suspend fun download(remoteName: String, targetFile: File) = false
}
