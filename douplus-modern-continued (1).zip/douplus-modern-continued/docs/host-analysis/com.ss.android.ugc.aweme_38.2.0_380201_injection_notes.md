# 当前宿主注入链说明（38.2.0 / 380201）

这份说明记录当前工程里已经写入的第一批真实安装候选。

## settings
- owner: `com.ss.android.ugc.aweme.comment.ui.common.CommentCommonSettingsDialog`
- method: `initItemView()`
- 用途：优先尝试作为“模块设置”入口注入点

- owner: `com.ss.android.ugc.aweme.im.business.menusettingpage.MenuEducationFragment`
- method: `onViewCreated(View, Bundle)`
- 用途：作为次级入口候选

## video
- owner: `com.ss.android.ugc.aweme.commentfeed.viewholder.OVideoPlayerModel`
- method: `onBind(...)`
- 用途：尝试视频信息面板与角标注入

- owner: `com.bytedance.ies.ugc.aweme.photos.detail.flow.page.comment.CommentListPresenter`
- method: `onBind(...)`
- 用途：尝试视频长按菜单相关联动

## comment
- owner: `com.ss.android.ugc.aweme.comment.adapter.CommentReplyButtonViewHolder`
- method: `onBind(...)`
- 用途：尝试评论长按菜单与评论增强入口

- owner: `com.ss.android.ugc.aweme.comment.ui.diggbury.DiggBuryViewDelegate`
- method: `onBind(...)`
- 用途：尝试评论菜单增强

## 说明
这些候选来自当前 base.apk 的静态字符串和类名粗筛，只是“先把安装链写通”的候选，仍需真机日志验证。
