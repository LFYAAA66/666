# 当前宿主分析：抖音 38.2.0 (380201)

这份信息来自用户上传的 `base.apk`，本地解析 `AndroidManifest.xml` 得到。

## 基础信息
- 包名：`com.ss.android.ugc.aweme`
- versionName：`38.2.0`
- versionCode：`380201`
- compileSdkVersion：`35`
- targetSdkVersion：`34`
- minSdkVersion：`23`
- Application：`com.ss.android.ugc.aweme.app.host.AwemeHostApplication`
- AppComponentFactory：`com.ss.android.ugc.aweme.app.host.AwemeAppComponentFactory`

## 当前对工程的直接影响
1. 规则目录已按 `rules/com.ss.android.ugc.aweme/380201/` 预留。
2. 适配诊断页里应把宿主标签显示为 `com.ss.android.ugc.aweme@380201`。
3. `SettingsEntryResolver`、`VideoResolver`、`CommentResolver` 的首轮定位应以这版 APK 为准。

## 下一步建议
- 先验证模块能在这版宿主里被 LSPosed 正确识别。
- 然后优先定位：设置入口、视频详情数据模型、评论 item 绑定点。
- 任何未确认的类名/方法名都继续保留为“待宿主定位”。
