# 参考模块静态摘要

- 入口: `io.kazutoiris.mrga.HookEntry_YukiHookXposedInit`
- DEX 数量: 8
- layout XML 数量: 61
- drawable XML 数量: 71

## 高密度命名空间

- `com/highcapable/yukihookapi/hook`: 110
- `com/highcapable/yukihookapi/YukiHookAPI`: 2
- `com/highcapable/yukihookapi/YukiHookAPI$Status`: 1
- `com/highcapable/yukihookapi/YukiHookAPI$Status$Executor`: 1
- `com/HighCapable/YukiHookAPI`: 1
- `com/apk/res/android`: 1
- `io/kazutoiris/mrga/HookEntry`: 1
- `io/kazutoiris/mrga/HookEntry$onHook$1$1$8$1`: 1
- `io/kazutoiris/mrga/HookEntry$onHook$1`: 1
- `io/kazutoiris/mrga/HookEntry_Impl`: 1

## 可参考的类名线索

- `classes.dex` `com.highcapable.yukihookapi.hook.xposed.prefs.YukiHookPrefsBridge$put$1`
- `classes.dex` `com.highcapable.yukihookapi.hook.xposed.prefs.YukiHookPrefsBridge$Editor`
- `classes.dex` `com.highcapable.yukihookapi.hook.xposed.prefs.YukiHookPrefsBridge`
- `classes.dex` `com.highcapable.yukihookapi.hook.xposed.prefs.YukiHookPrefsBridge$remove$2`
- `classes.dex` `com.highcapable.yukihookapi.hook.xposed.prefs.ui.ModulePreferenceFragment`
