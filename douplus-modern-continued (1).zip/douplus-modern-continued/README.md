
# DouPlus Modern One-Stop

这是一个尽量一次性补满的 LSPosed Modern API 抖音增强模块工程。

## 已完成
- Modern API 入口文件：`java_init.list` / `scope.list` / `module.prop`
- 多模块 Android 工程结构
- 当前宿主抖音 `38.2.0 / 380201` 的静态分析文档
- Room 数据层：插眼、分类、过滤规则、适配失败、备份索引
- 配置层：DataStore + Remote Preferences 分层
- 备份层：导出 / 导入 / 恢复校验 / WebDAV 门面
- 适配层：ResolverRegistry / AdapterEngine / TargetSet / Report
- 功能层：Settings / Video / Comment / Chat / Ward 的安装链
- GitHub Actions 自动打包（无需 Gradle Wrapper，直接安装 Gradle 8.7）
- 给小白的文档与本地脚本

## 当前宿主
- packageName: `com.ss.android.ugc.aweme`
- versionName: `38.2.0`
- versionCode: `380201`

## 还需要继续验证
- 当前宿主版本的真实 Hook 点是否命中
- 运行时日志回填规则
- 真机装模块后在 LSPosed 中的最终行为验证

## 最短路线
先看：`README-一步一步操作.md`

## 2026-04-03 继续推进：当前宿主注入链

这一轮新增了三条可继续定位的真实安装链：

- 设置入口注入：`SettingsEntryFeature` 现在会尝试解析并安装 `SettingsMenuHooker` / `SettingsBottomMenuHooker`
- 视频信息面板注入：`VideoFeature` 现在会尝试解析并安装 `VideoInfoPanelHooker` / `VideoLongPressMenuHooker`
- 评论长按菜单注入：`CommentFeature` 现在会尝试解析并安装 `CommentBindHooker` / `CommentMenuHooker`

当前抖音 `38.2.0 / 380201` 已写入一批静态候选：

- `CommentCommonSettingsDialog.initItemView()`
- `MenuEducationFragment.onViewCreated(...)`
- `OVideoPlayerModel.onBind(...)`
- `CommentReplyButtonViewHolder.onBind(...)`
- `DiggBuryViewDelegate.onBind(...)`

这些仍然属于“基于静态字符串与候选类的可尝试命中”，不是已经真机确认的最终 Hook 点。

## 2026-04-03 当前宿主注入链（继续版）

这一轮把“假装安装”改成了“尝试真实解析并安装 Hook”的链路：

- 通过 `HostSession.hookBridge` 统一走 `module.hook(...)`
- 通过 `HostReflectionResolver` 按 `MethodRef/FieldRef` 做反射解析
- 设置 / 视频 / 评论三个 Feature 在解析成功时会真正调用 `installMethodHook(...)`
- 对应 Hooker 已经补进：
  - `SettingsMenuHooker`
  - `SettingsBottomMenuHooker`
  - `VideoInfoPanelHooker`
  - `VideoLongPressMenuHooker`
  - `CommentBindHooker`
  - `CommentMenuHooker`

当前对抖音 `38.2.0 / 380201` 预写入了一批可尝试命中的 owner/method 候选，但仍需真机日志验证。
