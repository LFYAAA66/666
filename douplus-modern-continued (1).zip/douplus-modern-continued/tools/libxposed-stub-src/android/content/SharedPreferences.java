package android.content;
import java.util.Map;
public interface SharedPreferences {
    interface Editor {
        Editor putBoolean(String key, boolean value);
        Editor putString(String key, String value);
        Editor putInt(String key, int value);
        Editor apply();
    }
    Map<String, ?> getAll();
    boolean getBoolean(String key, boolean defValue);
    String getString(String key, String defValue);
    int getInt(String key, int defValue);
}
