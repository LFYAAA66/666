package io.github.libxposed.api;
import android.content.SharedPreferences;
import java.lang.reflect.Method;
public class XposedModule implements XposedInterface {
    protected final XposedInterface base;
    protected final XposedModuleInterface.ModuleLoadedParam moduleLoadedParam;
    public XposedModule(XposedInterface base, XposedModuleInterface.ModuleLoadedParam moduleLoadedParam) {
        this.base = base;
        this.moduleLoadedParam = moduleLoadedParam;
    }
    public void onModuleLoaded() {}
    public void onPackageLoaded(XposedModuleInterface.PackageLoadedParam param) {}
    public void onPackageReady(XposedModuleInterface.PackageReadyParam param) {}
    public void log(String message, Throwable throwable) {}
    public void log(String message) {}
    @Override public SharedPreferences getRemotePreferences(String group) { return base != null ? base.getRemotePreferences(group) : null; }
    @Override public Object hook(Method method, Class<? extends Hooker> hookerClass) { return base != null ? base.hook(method, hookerClass) : null; }
    @Override public boolean deoptimize(Method method) { return base != null && base.deoptimize(method); }
    @Override public DexParser parseDex(byte[] dexData, boolean includeAnnotations) { return base != null ? base.parseDex(dexData, includeAnnotations) : null; }
}
