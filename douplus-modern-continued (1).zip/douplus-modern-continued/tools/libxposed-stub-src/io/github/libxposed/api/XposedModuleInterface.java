package io.github.libxposed.api;
public interface XposedModuleInterface {
    interface ModuleLoadedParam {}
    interface PackageLoadedParam {
        String getPackageName();
        String getProcessName();
        boolean isFirstPackage();
    }
    interface PackageReadyParam {
        String getPackageName();
        String getProcessName();
        ClassLoader getClassLoader();
        boolean isFirstPackage();
    }
}
