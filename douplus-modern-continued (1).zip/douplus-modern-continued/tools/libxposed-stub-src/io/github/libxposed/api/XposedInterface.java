package io.github.libxposed.api;
import android.content.SharedPreferences;
import java.lang.reflect.Method;
public interface XposedInterface {
    default SharedPreferences getRemotePreferences(String group) { return null; }
    default Object hook(Method method, Class<? extends Hooker> hookerClass) { return null; }
    default boolean deoptimize(Method method) { return false; }
    default DexParser parseDex(byte[] dexData, boolean includeAnnotations) { return null; }
    interface Hooker {}
    interface BeforeHookCallback {
        Object[] getArgs();
        Object getThisObject();
        void setResult(Object result);
    }
    interface AfterHookCallback {
        Object[] getArgs();
        Object getThisObject();
        Object getResult();
        void setResult(Object result);
    }
    interface DexParser {}
}
